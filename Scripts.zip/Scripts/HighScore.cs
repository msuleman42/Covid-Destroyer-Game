using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class HighScore : MonoBehaviour
{
    // saving and loading into/from JSON file
    public static string directory = "/SaveData/";
    public static string fileName = "highScore.txt";
    private static List<HighScoreEntry> highScoreEntryList;
    
    public static List<HighScoreEntry> getHighScoreEntryList() {
        return highScoreEntryList;
    }

    private static void setHighScoreEntryList(List<HighScoreEntry> entryList) {
        highScoreEntryList = entryList;
    }

    private static List<HighScoreEntry> defaultEntryList = new List<HighScoreEntry>() {
                                new HighScoreEntry{ score = 0, name = "PLAYER1"},
                                new HighScoreEntry{ score = 0, name = "PLAYER2"},
                                new HighScoreEntry{ score = 0, name = "PLAYER3"},
                                new HighScoreEntry{ score = 0, name = "PLAYER4"},
                                new HighScoreEntry{ score = 0, name = "PLAYER5"},
                                new HighScoreEntry{ score = 0, name = "PLAYER6"},
                                new HighScoreEntry{ score = 0, name = "PLAYER7"},
                                new HighScoreEntry{ score = 0, name = "PLAYER8"},
                                new HighScoreEntry{ score = 0, name = "PLAYER9"},
                                new HighScoreEntry{ score = 0, name = "PLAYER10"},
    };

    // Save the highscoreEntryList in to a txt file in a JSON format
    public static void saveHSList() 
    {
        string dir = Application.persistentDataPath + directory;
        highScoreEntryList = sortHSList(highScoreEntryList);
        HighScoreFullList HSList = new HighScoreFullList{ listOfHSEntry = highScoreEntryList};
        if (!Directory.Exists(dir))
        {
            Directory.CreateDirectory(dir);
        }

        string json = JsonUtility.ToJson(HSList);
        File.WriteAllText(dir + fileName, json);
    }
    
    // Load list if it exists
    public static List<HighScoreEntry> loadHSList() 
    {
        string fullpath = Application.persistentDataPath + directory + fileName;
        HighScoreFullList HSList = new HighScoreFullList{};
        // If txt file exists, load the file in JSON format into the highScoreEntryList
        // If it doesnt exist, set the highScoreEntryList to the default list and save it
        if(File.Exists(fullpath)) 
        {
            //Debug.Log("FILE EXISTS");
            string json = File.ReadAllText(fullpath);
            HSList = JsonUtility.FromJson<HighScoreFullList>(json);
            // putting it into the list
            highScoreEntryList = HSList.listOfHSEntry;
        }
        else
        {
            //Debug.Log("FILE DOESNT EXIST");
            highScoreEntryList = defaultEntryList;
            saveHSList();
        }
        return highScoreEntryList;
    }

    // Add a highscore entry
    public static void addHSEntry(int newScore, string newName) 
    {
        HighScoreEntry singleEntry = new HighScoreEntry { score = newScore, name = newName};
        // load current list
        loadHSList();
        // add new entry to list
        highScoreEntryList.Add(singleEntry);
        // save the new list
        saveHSList();
    }

    // Check to see if the score is a highest score
    public static bool checkIfHighScore(int newScore)
    {
        // load current list
        loadHSList();
        int currentHS = highScoreEntryList[0].score;
        if (newScore > currentHS) {
            return true;
        }
        else { 
            return false;
        }
    }

    // Algorithm to sort the list based on the score highest to lowest
    private static List<HighScoreEntry> sortHSList (List<HighScoreEntry> unsortedEntryList) 
    {
        for (int i = 0; i < unsortedEntryList.Count; i++) {
            for (int j = i + 1; j < unsortedEntryList.Count; j++) {
                if (unsortedEntryList[j].score > unsortedEntryList[i].score) {
                    HighScoreEntry temp = unsortedEntryList[i];
                    unsortedEntryList[i] = unsortedEntryList[j];
                    unsortedEntryList[j] = temp;
                }
            }
        }
        List<HighScoreEntry> sortList = removeBottomOfList(unsortedEntryList);
        return sortList;
    }

    private static List<HighScoreEntry> removeBottomOfList(List<HighScoreEntry> entryList)
    {
        // remove entries from list below 10
        if (entryList.Count > 10)
        {
            for (int k = 10; k < entryList.Count; k++)
            {
                entryList.RemoveAt(k);
            }
            //Debug.Log("REMOVED ENTRY");
        }
        return entryList;
    }

    public static void DeleteSaveFile() 
    {
        // checks to see if file exists first
        string fullpath = Application.persistentDataPath + directory + fileName;
        if(File.Exists(fullpath)){
            //Debug.Log("DELETE FILE");
            File.Delete(fullpath);
        }
    }

    // List of highscore entries
    public class HighScoreFullList 
    {
        public List<HighScoreEntry> listOfHSEntry;
    }

    // Single highscore entry
    [System.Serializable]
    public class HighScoreEntry 
    {
        public int score = 0;
        public string name = "Commander";
    }
}
