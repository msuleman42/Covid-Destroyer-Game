using UnityEngine;
using UnityEngine.UI;

public class ComponentMethods
{
    // Text component
    public static GameObject createTextGO(GameObject go, string goName, GameObject goParent) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Text>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);

        return go;
    }
    
    public static GameObject createTextGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Text>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;

        return go;
    }

    public static GameObject createTextGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal, Vector3 positionLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Text>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;

        return go;
    }

    public static GameObject setTextProperties(GameObject go, string text, Font font, FontStyle style, int fontSize, TextAnchor allignment, Color textColor)
    {
        go.GetComponent<Text>().text = text;
        go.GetComponent<Text>().font = font;
        go.GetComponent<Text>().fontStyle = style;
        go.GetComponent<Text>().fontSize = fontSize;
        go.GetComponent<Text>().alignment = allignment;
        go.GetComponent<Text>().color = textColor;

        return go;
    }

    // Image component
    public static GameObject createImageGO(GameObject go, string goName, GameObject goParent) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);

        return go;
    }

    public static GameObject createImageGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;

        return go;
    }

    public static GameObject createImageGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal, Vector3 positionLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;

        return go;
    }

    // Button Component
    public static GameObject createButtonGO(GameObject go, string goName, GameObject goParent) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.AddComponent<Button>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);

        return go;
    }

    public static GameObject createButtonGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.AddComponent<Button>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;

        return go;
    }

    public static GameObject createButtonGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal, Vector3 positionLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.AddComponent<Button>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;

        return go;
    }

    // Input Field component
    public static GameObject createInputFieldGO(GameObject go, string goName, GameObject goParent) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.AddComponent<InputField>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);

        return go;
    }

    public static GameObject createInputFieldGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.AddComponent<InputField>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;

        return go;
    }

    public static GameObject createInputFieldGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal, Vector3 positionLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<Image>();
        go.AddComponent<InputField>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;

        return go;
    }
    
    // Empty component/component holder
    public static GameObject createEmptyGO(GameObject go, string goName, GameObject goParent) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);

        return go;
    }

    public static GameObject createEmptyGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;

        return go;
    }

    public static GameObject createEmptyGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal, Vector3 positionLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;

        return go;
    }

    public static GameObject createEmptyGO(GameObject go, string goName, GameObject goParent, Vector3 scaleLocal, Vector3 positionLocal, Vector2 sizeRect) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;
        go.GetComponent<RectTransform>().sizeDelta = sizeRect;

        return go;
    }

    // Sprite component
    public static GameObject createSpriteGO(GameObject go, string goName, GameObject goParent, string sortLayer) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<SpriteRenderer>();
        go.GetComponent<SpriteRenderer>().sortingLayerName = sortLayer;
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);

        return go;
    }

    public static GameObject createSpriteGO(GameObject go, string goName, GameObject goParent, string sortLayer, Vector3 scaleLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<SpriteRenderer>();
        go.GetComponent<SpriteRenderer>().sortingLayerName = sortLayer;
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;

        return go;
    }

    public static GameObject createSpriteGO(GameObject go, string goName, GameObject goParent, string sortLayer, Vector3 scaleLocal, Vector3 positionLocal) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<SpriteRenderer>();
        go.GetComponent<SpriteRenderer>().sortingLayerName = sortLayer;
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;

        return go;
    }

    public static GameObject createSpriteGO(GameObject go, string goName, GameObject goParent, string sortLayer, Vector3 scaleLocal, Vector3 positionLocal, Vector2 sizeRect) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<SpriteRenderer>();
        go.GetComponent<SpriteRenderer>().sortingLayerName = sortLayer;
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = scaleLocal;
        go.transform.localPosition = positionLocal;
        go.GetComponent<RectTransform>().sizeDelta = sizeRect;

        return go;
    }
    
    // Box Collider Component for walls
    public static GameObject createBoxColliderGO(GameObject go, string goName, GameObject goParent) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<BoxCollider2D>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);

        return go;
    }

    public static GameObject createBoxColliderGO(GameObject go, string goName, GameObject goParent, Vector2 boxColliderSize) 
    {
        go.name = goName;
        go.AddComponent<RectTransform>();
        go.AddComponent<CanvasRenderer>();
        go.AddComponent<BoxCollider2D>();
        go.transform.SetParent(goParent.transform);
        go.transform.localScale = new Vector3(1f, 1f, 1f);
        go.GetComponent<BoxCollider2D>().size = boxColliderSize;

        return go;
    }

    // Set gameObject position from parent
    public static GameObject setPositionFromParent(GameObject go, RectTransform.Edge edge1, float edge1Inset, float edge1Size, 
                                                    RectTransform.Edge edge2, float edge2Inset, float edge2Size)
    {
        go.GetComponent<RectTransform>().SetInsetAndSizeFromParentEdge(edge1, edge1Inset, edge1Size);
        go.GetComponent<RectTransform>().SetInsetAndSizeFromParentEdge(edge2, edge2Inset, edge2Size);

        return go;
    }

}
