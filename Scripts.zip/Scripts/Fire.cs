using UnityEngine;

public class Fire : MonoBehaviour
{
    [SerializeField]
    private float direction; // 1 to shoot up (player), -1 to shoot down (enemy)
    [SerializeField]
    private float speed;
    [SerializeField]
    private Rigidbody2D rbBullet;

    void Start()
    {
        // set bullet velocity to be at the given speed, either up (for the player) or down (for the enemy)
        rbBullet.velocity = direction * transform.up * speed;
    }

    void OnTriggerEnter2D (Collider2D col) 
    {
        // destroy this gameobject as long as the thing it collided with was not another bullet
        if (col.gameObject.tag != "Bullet" && col.gameObject.tag != "PlayerBullet") {
            //Debug.Log(col.name);
            Destroy(gameObject);
        }

        // if bullet hits enemy it was the player that instantiated that bullet, so +20points, 
        // else if the bullet hits the player, the enemy instatiated it, so -3points,
        // else if the bullet hits the top wall, the player instantiated the bullet so -1point
        if (col.gameObject.tag == "Enemy") {
            GameController.getInstance().AddScore(20);
        }
        else if (col.gameObject.tag == "Player") {
            GameController.getInstance().AddScore(-3);
        }
        else if (col.gameObject.tag == "TopWall") {
            GameController.getInstance().AddScore(-1);
        }
    }
}
