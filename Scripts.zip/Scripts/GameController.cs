using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    // singleton pattern
    static GameController instance;

    public static GameController getInstance() {
        return instance;
    }

    void Awake() 
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else 
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    // method to destroy instance when player dies or when returning to title screen
    public void DestroyInstance()
    {
        Destroy(this.gameObject);
    }

    // saving and loading
    public void SaveGame()
    {
        SaveController.Save();
    }
    public bool canLoadGame()
    {
        return SaveController.canLoad();
    }
    public bool LoadGame()
    {
        return SaveController.Load();
    }

    // Delete the player data file
    public void DeletePlayerFile()
    {
        SaveController.DeleteSaveFile();
    }
    
    // Delete the player data file
    public void DeleteHSFile()
    {
        HighScore.DeleteSaveFile();
    }

    // Get the high score list
    public List<HighScore.HighScoreEntry> getHighScoreList() 
    {
        return HighScore.loadHSList();
    }
    // Update the highscore list with new entry
    public void addHighScore()
    {
        HighScore.addHSEntry(score, playerName);
    }
    // Check to see if the score is the new high score
    public bool isHighScore() 
    {
        int currentHighScore = getHighScoreList()[0].score;
        //Debug.Log(currentHighScore);
        if (score >= currentHighScore) {
            return true;
        }
        else {
            return false;
        }
    }


    // Default player values and values that are saved
    public string playerName {get; set;} = "";
    public int score {get; private set;} = 0;
    public LevelsEnum levelNumber {get; set;} = LevelsEnum.LevelOne;
    public WeaponsEnum weaponType {get; set;} = WeaponsEnum.Pistol;
    public int maxHealth {get; private set;} = 100;
    public bool hasShield {get; set;} = false;
    public int shield {get; private set;}
    public int maxShield {get; private set;} = 100;
    public float movementSpeed {get; set;} = 5f;
    public int numSpeedUpgrades { get; set; } = 0;

    // Values which don't need to be saved
    public int health { get; private set; } // player health doesn't need saving because it gets reset at the start of each level
    public int enemyHealth {get; set;}
    public bool playerDead { get; set; } = false;
    public bool enemyDead { get; set; } = false;
    public bool highScoreRecorded { get; set; } = false;
    public bool inInvincibilityMode { get; set; } = false;

    // Add to score method
    public void AddScore(int scoreToAdd)
    {
        score += scoreToAdd;
        if (score < 0){
            score = 0;
        }
    }
    public void setScore(int scoreVal)
    {
        score = scoreVal;
    }

    // Health and shield methods
    public void AddHealth(int healthToAdd)
    {
        health += healthToAdd;
        if(health < 0) {
            health = 0;
        }
    }
    public void AddShield(int shieldToAdd)
    {
        shield += shieldToAdd;
        if(shield < 0) {
            shield = 0;
        }
    }
    public void AddEnemyHealth(int healthToAdd)
    {
        enemyHealth += healthToAdd;
        if (enemyHealth < 0) {
            enemyHealth = 0;
        }
    }
    public void setHealth(int healthVal)
    {
        health = healthVal;
    }
    public void setMaxHealth(int maxHealthVal)
    {
        maxHealth = maxHealthVal;
    }
    public void setShield(int shieldVal)
    {
        shield = shieldVal;
    }
    public void setMaxShield(int maxShieldVal)
    {
        maxShield = maxShieldVal;
    }


    

}
