using System;
using UnityEngine;
using UnityEngine.Audio;

public class AudioController : MonoBehaviour
{
    // singleton pattern to hold data
    static AudioController _instance;

    public static AudioController getInstance() 
    {
        return _instance;
    }

    void Awake()
    {
        if (_instance != null)
        {
            Destroy(gameObject);
        }
        else 
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    public void DestroyInstance()
    {
        Destroy(this.gameObject);
    }

    [SerializeField] 
    private AudioMixer mixer;
    [SerializeField]
    private string volumeParameterMusic = "MusicVolume";
    [SerializeField]
    private string volumeParameterSFX = "SFXVolume";

    public static event Action<bool> inGameMusicChange;
    public static event Action<WeaponsEnum> playerOnShoot;
    public static event Action enemyOnShoot;
    public static event Action playerOnDeath;
    public static event Action enemyOnDeath;

    // Sound volume values set in the settings
    public float backgroundMusicVolume {get; set;} = 0.75f;
    public float soundEffectsVolume {get; set;} = 0.75f;

    // Set background music volume
    public void setBackgroundMusicVolume(float volume) 
    {
        backgroundMusicVolume = volume;
        mixer.SetFloat(volumeParameterMusic, Mathf.Log10(volume) * 20f);
    }
    // set sound effects volume
    public void setSoundEffectsVolume(float volume)
    {
        soundEffectsVolume = volume;
        mixer.SetFloat(volumeParameterSFX, Mathf.Log10(volume) * 20f);
    }

    // Invoke method of background music. Input = true to play InGame music. Input = false to play title screen music
    public void changeBackgroundMusic(bool inGame) 
    {
        inGameMusicChange?.Invoke(inGame);
    }

    // Invoke method when player shoots depending on the weapon
    public void playerShoot(WeaponsEnum weaponType)
    {
        playerOnShoot?.Invoke(weaponType);
    }
    
    // Invoke method when enemy shoots
    public void enemyShoot() 
    {
        enemyOnShoot?.Invoke();
    }

    // Invoke method when player dies
    public void playerDeath() 
    {
        playerOnDeath?.Invoke();
    }

    // Invoke method when enemy dies
    public void enemyDeath() 
    {
        enemyOnDeath?.Invoke();
    }
    
}
