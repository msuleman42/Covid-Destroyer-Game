using System.Collections;
using UnityEngine;

// Enemy shoots 2 bullets at a random angle at a random time between 0.2 and 2secs
// Bullets aim at player
public class EnemyShootL4 : MonoBehaviour
{
    private GameObject enemyBullet1;
    private WaitForSeconds delay1 = new WaitForSeconds(0.15f); // rage mode time between bullets
    private WaitForSeconds delay2 = new WaitForSeconds(0.2f); // normal mode time between 1st and 2nd bullet
    private WaitForSeconds delay3 = new WaitForSeconds(0.3f); // rage mode wait
    private WaitForSeconds delay4 = new WaitForSeconds(10f);
    private bool inNormalMode = false;

    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;
    [SerializeField]
    private Animator animator;

    void Start() 
    {
        StartCoroutine(L4Shoot());
    }

    private void Shoot() 
    {
        // instantiate bullet that aims at the players current position
        if (firePoint != null) {
            enemyBullet1 = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);
            enemyBullet1.transform.SetParent(this.transform);
            enemyBullet1.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
            AudioController.getInstance().enemyShoot();
        }
    }

    private IEnumerator L4Shoot() 
    {
        // Start with normal mode, wait for 10secs, stop normal mode, enter rage mode and wait until it finishes to return to normal mode
        while (firePoint != null) {
            inNormalMode = true;
            StartCoroutine(normalMode());
            yield return delay4;
            inNormalMode = false;
            yield return StartCoroutine(rageMode());
        }
    }

    private IEnumerator normalMode()
    {
        // Shoot a targeted bullet then waits for random time
        yield return new WaitForSeconds(1f);
        while(inNormalMode) {
            Shoot();
            yield return new WaitForSeconds(Random.Range(0.2f, 1.2f));
        }
    }

    private IEnumerator rageMode() 
    {
        // Set animation of enemy to indicate rage mode then wait for 0.3s
        animator.SetBool("Rage", true);
        yield return delay3;
        // shoot bullet every 0.15sec 11 times
        for (int i = 0; i < 12; i++) {
            Shoot();
            yield return delay1;
        }
        // return animation to idle state
        animator.SetBool("Rage", false);
    }

    
}
