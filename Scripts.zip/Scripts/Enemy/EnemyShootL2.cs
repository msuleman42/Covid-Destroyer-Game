using System.Collections;
using UnityEngine;

// Enemy shoots 2 bullets slightly spread straight down every 1 second
public class EnemyShootL2 : MonoBehaviour
{
    private GameObject enemyBullet1;
    private GameObject enemyBullet2;
    private WaitForSeconds delay = new WaitForSeconds(1f); // time between shots

    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;

    void Start() 
    {
        StartCoroutine(L2Shoot());
    }


    private void Shoot() 
    {
        // instantiate bullets at angle to spread them
        enemyBullet1 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, 2f));
        enemyBullet1.transform.SetParent(this.transform);
        enemyBullet1.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        enemyBullet2 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, -2f));
        enemyBullet2.transform.SetParent(this.transform);
        enemyBullet2.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        AudioController.getInstance().enemyShoot();
    }

    private IEnumerator L2Shoot()
    {
        // Shoot the bullets while the firepoint exists and wait for 1s
        yield return new WaitForSeconds(1f);
        while(firePoint != null) {
            Shoot();
            yield return delay;
        }
    }
}
