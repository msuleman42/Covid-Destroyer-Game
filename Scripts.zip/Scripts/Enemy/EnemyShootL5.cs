using System.Collections;
using UnityEngine;

// Enemy shoots 2 bullets at a random angle at a random time between 0.2 and 2secs
// Bullets aim at player
// Invinsibility mode where enemy doesnt take damage

public class EnemyShootL5 : MonoBehaviour
{
    private GameObject enemyBullet1;
    private WaitForSeconds delay1 = new WaitForSeconds(0.15f); // rage mode time between bullets
    private WaitForSeconds delay2 = new WaitForSeconds(0.2f); // normal mode time between 1st and 2nd bullet
    private WaitForSeconds delay3 = new WaitForSeconds(5f); // in invisible mode
    private WaitForSeconds delay4 = new WaitForSeconds(15f); // wait between invinsible mode
    public static bool inInvinsibilityMode {get; private set;} = false;

    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;
    [SerializeField]
    private Animator animator;

    void Start() 
    {
        StartCoroutine(L5Shoot());
        StartCoroutine(invincibilityMode());
    }

    private void Shoot() 
    {
        // instantiate bullet that aims at the players current position
        if (firePoint != null) {
            enemyBullet1 = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);
            enemyBullet1.transform.SetParent(this.transform);
            enemyBullet1.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
            AudioController.getInstance().enemyShoot();
        }
    }

    private IEnumerator L5Shoot() 
    {
        // Shoot targeted bullet, waits for 0.2s, shoots another targeted bullet, then waits for random time
        yield return new WaitForSeconds(1f);
        while (firePoint != null) {
            Shoot();
            yield return delay2;
            Shoot();
            yield return new WaitForSeconds(Random.Range(0.3f, 2f));
        }
        
    }

    private IEnumerator invincibilityMode() 
    {
        // Set animation of enemy to indicate invicibility mode, set the bool in game controller, for 5secs.
        // delay 15secs between invinsibility modes
        yield return delay4;
        while (firePoint != null) {
            animator.SetBool("Invinsible", true);
            GameController.getInstance().inInvincibilityMode = true;
            yield return delay3;
            animator.SetBool("Invinsible", false);
            GameController.getInstance().inInvincibilityMode = false;
            yield return delay4;
        }
    }
}
