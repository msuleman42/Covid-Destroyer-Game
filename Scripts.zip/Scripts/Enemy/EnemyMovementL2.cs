using UnityEngine;

// Enemy moves left to right only changing direction when it collides with the side walls. 
// Enemy speeds up as health decreases
public class EnemyMovementL2 : MonoBehaviour
{
    private int direction; // 1 to move right, -1 to move left
    private float speed;
    [SerializeField]
    private Rigidbody2D enemyRB;
    
    void Start()
    {
        speed = 2f;
        direction = 1;
        enemyRB.velocity = direction * transform.right * speed;
    }

    void Update() {
        // if the enemy health drops below 0, stop the enemy movement
        if (GameController.getInstance().enemyHealth <= 0) {
            speed = 0;
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    private void OnCollisionEnter2D (Collision2D col)
    {
        // if the enemy collides with a wall, change direction
        if(col.gameObject.tag.Equals("Wall")) {
            direction *= -1;
            speed = speedUp(GameController.getInstance().enemyHealth);
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    private float speedUp(int healthValue) 
    {
        // speed up depending on the enemy's health. L2 enemy health = 200
        if (healthValue <= 75) {
            return 4f;
        }
        else if (healthValue <= 150) {
            return 3f;
        }
        else {
            return 2f;
        }
    }
}
