using System.Collections;
using UnityEngine;

// Enemy moves at a constant speed throughout. Enemy can change direction every 2 secs. 
// if direction = 0 enemy stays still, if direction = 1 enemy moves right and if direction = -1 enemy moves left
public class EnemyMovementL3 : MonoBehaviour
{
    private int direction; // 1 to move right, -1 to move left, 0 for stay still
    private float speed;
    [SerializeField]
    private Rigidbody2D enemyRB;
    
    void Start()
    {
        speed = 3f;
        StartCoroutine(L3Move());
    }

    void Update() {
        // if the enemy health drops below 0, stop the enemy movement
        if (GameController.getInstance().enemyHealth <= 0) {
            speed = 0;
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    private void OnCollisionEnter2D (Collision2D col)
    {
        // if the enemy collides with a wall, change direction
        if(col.gameObject.tag.Equals("Wall")) {
            direction *= -1;
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    private int randChangeDirection() 
    {
        return Random.Range(-1, 2); // choose a value of -1, 0 or 1 at random
    }

    private IEnumerator L3Move() 
    {
        // choose a rand direction and move/stay accordingly
        direction = randChangeDirection();
        enemyRB.velocity = direction * transform.right * speed;
        yield return new WaitForSeconds(2f);
        while (GameController.getInstance().enemyDead != true) {
            direction = randChangeDirection();
            enemyRB.velocity = direction * transform.right * speed;
            yield return new WaitForSeconds(2f);
        }
    }
}
