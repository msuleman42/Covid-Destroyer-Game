using System.Collections;
using UnityEngine;

// Enemy speeds up as health decreases. Enemy can change direction at a random time. 
// There is a bias to the new direction. 10% chance to have the same direction and a 45% chance for
// each of the other directions

public class EnemyMovementL4 : MonoBehaviour
{
    private int direction; // 1 to move right, -1 to move left, 0 for stay still
    private float speed;
    private readonly int ratioChanceLow = 10;
    private readonly int ratioChanceNormal = 45;
    [SerializeField]
    private Rigidbody2D enemyRB;
    
    void Start()
    {
        speed = 2f; // starting speed
        StartCoroutine(L4Move());
    }

    void Update() {
        // if the enemy health drops below 0, stop the enemy movement
        if (GameController.getInstance().enemyHealth <= 0) {
            speed = 0;
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    private void OnCollisionEnter2D (Collision2D col)
    {
        // if the enemy collides with a wall, change direction
        if(col.gameObject.tag.Equals("Wall")) {
            direction *= -1;
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    private IEnumerator L4Move() 
    {
        // choose a rand direction and move/stay accordingly and wait for a random amount of time to change again
        direction = randChangeDirection();
        enemyRB.velocity = direction * transform.right * speed;
        yield return new WaitForSeconds(Random.Range(1f, 4f));
        while (GameController.getInstance().enemyDead != true) {
            direction = biasRandChangeDirection(direction); // choose new direction
            speed = speedUp(GameController.getInstance().enemyHealth); //change speed if health is low enough
            enemyRB.velocity = direction * transform.right * speed;
            yield return new WaitForSeconds(Random.Range(1f, 4f));
        }
    }

    private int randChangeDirection() 
    {
        return Random.Range(-1, 2); // choose a value of -1, 0 or 1 at random
    }

    private int biasRandChangeDirection(int currentDirection)
    {
        int otherDirection1;
        int otherDirection2;
        // set other directions based on what the current direction is
        if (currentDirection == 0) {
            otherDirection1 = -1;
            otherDirection2 = 1;
        }
        else if (currentDirection == 1) {
            otherDirection1 = -1;
            otherDirection2 = 0;
        }
        else {
            otherDirection1 = 0;
            otherDirection2 = 1;
        }
        // Generate random number from 0-100 and set the new direction on a bias
        int randomNumber = Random.Range(0, 101);

        if(randomNumber < ratioChanceLow) {
            return currentDirection;
        }
        else if (randomNumber < ratioChanceLow + ratioChanceNormal) {
            return otherDirection1;
        }
        else {
            return otherDirection2;
        }
    }

    private float speedUp(int healthValue) 
    {
        // speed up depending on the enemy's health. L4 = 400 health
        if (healthValue <= 100) {
            return 4f;
        }
        else if (healthValue <= 200) {
            return 3.5f;
        }
        else if (healthValue <= 300) {
            return 3.0f;
        }
        else {
            return 2f;
        }
    }
}
