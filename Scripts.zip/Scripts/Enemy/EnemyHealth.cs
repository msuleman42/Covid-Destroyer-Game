using System.Collections;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    private int weaponDamage;
    private bool isAlive = true;
    [SerializeField]
    private Animator animator;

    void Awake() 
    {
        // Set the enemy health depending on the level its on
        switch(GameController.getInstance().levelNumber) {
            case LevelsEnum.LevelOne:
                GameController.getInstance().enemyHealth = AssetsHolder.getInstance().enemyHealthL1;
            break;
            case LevelsEnum.LevelTwo:
                GameController.getInstance().enemyHealth = AssetsHolder.getInstance().enemyHealthL2;
            break;
            case LevelsEnum.LevelThree:
                GameController.getInstance().enemyHealth = AssetsHolder.getInstance().enemyHealthL3;
            break;
            case LevelsEnum.LevelFour:
                GameController.getInstance().enemyHealth = AssetsHolder.getInstance().enemyHealthL4;
            break;
            case LevelsEnum.LevelFive:
                GameController.getInstance().enemyHealth = AssetsHolder.getInstance().enemyHealthL5;
            break;
            case LevelsEnum.LevelSix:
                GameController.getInstance().enemyHealth = AssetsHolder.getInstance().enemyHealthL6;
            break;
        }

        // Set the damage taken by the enemy depending on the weapon the player has
        switch(GameController.getInstance().weaponType) {
            case WeaponsEnum.Pistol:
                weaponDamage = AssetsHolder.getInstance().pistolDamage;
            break;
            case WeaponsEnum.DualPistol:
                weaponDamage = AssetsHolder.getInstance().dualPistolDamage;
            break;
            case WeaponsEnum.Rifle:
                weaponDamage = AssetsHolder.getInstance().rifleDamage;
            break;
            case WeaponsEnum.Shotgun:
                weaponDamage = AssetsHolder.getInstance().shotgunDamage;
            break;
        }
    }

    // // NEED TO DELETE THIS UPDATE METHOD--------------------
    // // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            TakeDamage(90);
        }

        if (Input.GetKeyDown(KeyCode.Y))
        {
            GameController.getInstance().AddScore(1000);
        }
    }

    private void TakeDamage(int damage)
    {
        // Decrease enemy health when taking damage
        GameController.getInstance().AddEnemyHealth(-damage);
    }

    private void OnTriggerEnter2D (Collider2D col)
    {
        if (GameController.getInstance().inInvincibilityMode) {
            // if enemy is in invicibility mode then dont do anything
            return;
        }
        // if the object that collides with the enemy is a bullet then enemy takes damage
        if(col.gameObject.tag.Equals("PlayerBullet")) {
            TakeDamage(weaponDamage);
            // if enemy health is 0 or less, destroy the object
            if(GameController.getInstance().enemyHealth <= 0) {
                StartCoroutine(onDeath());
            }
        }
    }

    private IEnumerator onDeath()
    {
        // Debug.Log("Enemy Dead");
        // On death do this:
        if(isAlive) {
            // Destroy all children (the bullets)
            foreach (Transform child in gameObject.transform) {
                GameObject.Destroy(child.gameObject);
            }
            // play death animation and sound and wait for it to finish before destroying object
            animator.SetBool("Death", true);
            AudioController.getInstance().enemyDeath();
            isAlive = false;
            yield return new WaitForSeconds(2f);
            GameController.getInstance().enemyDead = true;
            Destroy(gameObject);
        }
    }
}
