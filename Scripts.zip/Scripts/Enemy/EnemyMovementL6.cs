using System.Collections;
using UnityEngine;

// Enemy speeds up as health decreases. Enemy can change direction at a random time.
// Enemy can "dodge" bullets if it detects a bullet coming by increasing the speed 
//Enemy moves forward a bit when enemy loses 100 health

public class EnemyMovementL6 : MonoBehaviour
{
    private int direction; // 1 to move right, -1 to move left, 0 for stay still
    private float speed;
    private float dodgeSpeed = 7f;
    private readonly int ratioChanceLow = 10;
    private readonly int ratioChanceNormal = 45;
    private Vector3 raycastOffset = new Vector3(0f, -4f, 0f); 
    private float nextDodge = 0.0f;
    private float dodgeRate = 1.5f; // can only dodge every 1.5 secs
    private Vector3 moveForwardOffset = new Vector3(0f, -0.75f, 0f);
    private bool hasMoved300 = false;
    private bool hasMoved200 = false;
    private bool hasMoved100 = false;
    private bool canMove = false;
    private bool isDodging = false;
    private WaitForSeconds delay1 = new WaitForSeconds(0.5f); // dodging time
    [SerializeField]
    private Rigidbody2D enemyRB;

    void Start()
    {
        speed = 2f; // starting speed
        canMove = true;
        StartCoroutine(L6Move());
    }

    void Update() {
        // if the enemy health drops below 0, stop the enemy movement
        if (GameController.getInstance().enemyHealth <= 0) {
            speed = 0;
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    void FixedUpdate() 
    {
        // Raycast as a circle some distance infront of the enemy. Used to detect if a bullet is coming at enemy
        RaycastHit2D hit = Physics2D.CircleCast(gameObject.transform.position + raycastOffset, 0.7f, -Vector2.up);
        // if raycast picks up an object and it is a bullet start to dodge
        if (Time.time > nextDodge && hit.collider != null && hit.collider.gameObject.tag == "PlayerBullet") {
            nextDodge = Time.time + dodgeRate;
            StartCoroutine(Dodge());
        }
    }

    private IEnumerator L6Move() 
    {
        // choose a rand direction and move/stay accordingly and wait for a random amount of time to change again
        direction = randChangeDirection();
        enemyRB.velocity = direction * transform.right * speed;
        yield return new WaitForSeconds(Random.Range(1f, 4f));
        while (GameController.getInstance().enemyDead != true && canMove) {
            // if the enemy isnt already in the dodging state move randomly, else wait for next frame
            if (isDodging != true) {
                direction = biasRandChangeDirection(direction); // choose new direction
                speedUpAndMoveForward(GameController.getInstance().enemyHealth); //change speed if health is low enough
                enemyRB.velocity = direction * transform.right * speed;
                yield return new WaitForSeconds(Random.Range(1f, 4f));
            }
            else {
                yield return new WaitForFixedUpdate();
            }
        }
    }

    private IEnumerator Dodge() 
    {
        // Set speed to 7f and if the enemy is currently stationary choose a direction to move in high speed
        isDodging = true;
        speed = dodgeSpeed;
        if (direction == 0) {
            direction = changeDirection();
        }
        enemyRB.velocity = direction * transform.right * speed;
        yield return delay1;
        // return back to normal speed
        speedUpAndMoveForward(GameController.getInstance().enemyHealth);
        enemyRB.velocity = direction * transform.right * speed;
        isDodging = false;
    }

    private void OnCollisionEnter2D (Collision2D col)
    {
        // if the enemy collides with a wall, change direction
        if(col.gameObject.tag.Equals("Wall")) {
            direction *= -1;
            enemyRB.velocity = direction * transform.right * speed;
        }
    }

    private int randChangeDirection() 
    {
        return Random.Range(-1, 2); // choose a value of -1, 0 or 1 at random
    }

    private int biasRandChangeDirection(int currentDirection)
    {
        int otherDirection1;
        int otherDirection2;
        // set other directions based on what the current direction is
        if (currentDirection == 0) {
            otherDirection1 = -1;
            otherDirection2 = 1;
        }
        else if (currentDirection == 1) {
            otherDirection1 = -1;
            otherDirection2 = 0;
        }
        else {
            otherDirection1 = 0;
            otherDirection2 = 1;
        }
        // Generate random number from 0-100 and set the new direction on a bias
        int randomNumber = Random.Range(0, 101);

        if(randomNumber < ratioChanceLow) {
            return currentDirection;
        }
        else if (randomNumber < ratioChanceLow + ratioChanceNormal) {
            return otherDirection1;
        }
        else {
            return otherDirection2;
        }
    }

    private int changeDirection() 
    {
        // only called if the current direction is 0 (i.e. if enemy is stationary)
        int randomNumber = Random.Range(0, 1);
        if (randomNumber == 0) {
            return -1;
        }
        else {
            return 1;
        }
    }

    private void speedUpAndMoveForward(int healthValue) 
    {
        // speed up depending on the enemy's health. L6 = 400 health
        // Every 100 health the enmy loses, it moves forward towards the player once
        if (healthValue <= 100) {
            speed = 5f;
            if(hasMoved100 != true) {
                StartCoroutine(moveForward());
                hasMoved100 = true;
            }
        }
        else if (healthValue <= 200) {
            speed = 4f;
            if(hasMoved200 != true) {
                StartCoroutine(moveForward());
                hasMoved200 = true;
            }
        }
        else if (healthValue <= 300) {
            speed = 3f;
            if(hasMoved300 != true) {
                StartCoroutine(moveForward());
                hasMoved300 = true;
            }
        }
        else {
            speed = 2f;
        }
    }

    private IEnumerator moveForward() 
    {
        canMove = false;
        enemyRB.velocity = new Vector2(0f, 0f);
        // Move enemy gameobject down towards the player by a certain amount over time
        Vector3 targetPos = gameObject.transform.position + moveForwardOffset;
        while(gameObject.transform.position.y > targetPos.y) {
            enemyRB.velocity = -transform.up * 3f;
            yield return new WaitForFixedUpdate();
        }
        canMove = true;
        StartCoroutine(L6Move());
    }

    // private void OnDrawGizmos() 
    // {
    //     Gizmos.color = Color.blue;
    //     Gizmos.DrawSphere(gameObject.transform.position + offset, 0.7f);
    // }
}
