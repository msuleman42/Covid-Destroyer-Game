using System.Collections;
using UnityEngine;

// Enemy shoots 3 bullets slightly spread straight down at a random time between 0.2 and 2secs
public class EnemyShootL3 : MonoBehaviour
{
    private GameObject enemyBullet1;
    private GameObject enemyBullet2;
    private GameObject enemyBullet3;

    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;

    void Start() 
    {
        StartCoroutine(L3Shoot());
    }


    private void Shoot() 
    {
        // instantiate bullets at angle to spread them
        enemyBullet1 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, 4f)); //firePoint.rotation
        enemyBullet1.transform.SetParent(this.transform);
        enemyBullet1.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        enemyBullet2 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, -4f));
        enemyBullet2.transform.SetParent(this.transform);
        enemyBullet2.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        enemyBullet3 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, 0f));
        enemyBullet3.transform.SetParent(this.transform);
        enemyBullet3.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        AudioController.getInstance().enemyShoot();
    }

    private IEnumerator L3Shoot()
    {
        // Shoot the bullets while the firepoint exists and wait for random time
        yield return new WaitForSeconds(1f);
        while(firePoint != null) {
            Shoot();
            yield return new WaitForSeconds(Random.Range(0.2f, 2f));
        }
    }
}
