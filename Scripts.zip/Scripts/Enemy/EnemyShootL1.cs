using System.Collections;
using UnityEngine;

public class EnemyShootL1 : MonoBehaviour
{
    private GameObject enemyBullet;
    private WaitForSeconds delay = new WaitForSeconds(0.25f); // time between shots
    private float angleChange = 5f; // change of angle after each shot
    private float angleShift = 35f; 
    private int counter;
    private int counterMax = 13; // goes from 30 to -30 degrees in increments of 5deg
    private int counterMin = 1;
    private bool counterSwitch;

    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;

    void Start() 
    {
        counter = counterMax; 
        counterSwitch = false; // change direction (i.e. clockwise/anticlockwise)
        StartCoroutine(L1Shoot());
    }

    private GameObject InstAtAngle(float angle)
    {
        return Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, angle));
    }

    private void ShootAtAngle(float angle)
    {
        // Instantiate bullet at angle and play enemy shooting sound
        enemyBullet = InstAtAngle(angle);
        enemyBullet.transform.SetParent(this.transform);
        enemyBullet.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        AudioController.getInstance().enemyShoot();
    }

    private IEnumerator L1Shoot()
    {
        // Shoot the bullet and set the angle of the next bullet while the firepoint exists
        yield return new WaitForSeconds(1f); // delay before start shooting
        while(firePoint != null) {
            ShootAtAngle((counter * angleChange) - angleShift);
            if(counterSwitch == false) {
                counter++;
                if (counter > counterMax) {
                    counterSwitch = true;
                    counter = counterMax;
                }
            }
            else {
                counter--;
                if (counter < counterMin) {
                    counterSwitch = false;
                    counter = counterMin;
                }
            }
            yield return delay;
        }
    }
}
