using UnityEngine;

public class AssetsHolder : MonoBehaviour
{
    // singleton pattern to hold data
    static AssetsHolder _instance;

    public static AssetsHolder getInstance() 
    {
        return _instance;
    }

    void Awake()
    {
        if (_instance != null)
        {
            Destroy(gameObject);
        }
        else 
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    public void DestroyInstance()
    {
        Destroy(this.gameObject);
    }

    // Reference screen resolution
    public float refSH {get; private set;}  = 720f;
    public float refSW {get; private set;} = 1280f;
    public float canvasScaleFactor {get; private set;} = 72f;
    // Backgrounds
    public Sprite StoryScreenBackground;
    public Sprite TitleScreenBackground;
    public Sprite LevelOneBackground;
    public Sprite LevelTwoBackground;
    public Sprite LevelThreeBackground;
    public Sprite LevelFourBackground;
    public Sprite LevelFiveBackground;
    public Sprite LevelSixBackground;

    // Titles
    public Sprite GameTitle;
    public Sprite LevelOneTitle;
    public Sprite LevelTwoTitle;
    public Sprite LevelThreeTitle;
    public Sprite LevelFourTitle;
    public Sprite LevelFiveTitle;
    public Sprite LevelSixTitle;
    public Sprite GameOverTitle;

    // Buttons/Images
    public Sprite NewGame;
    public Sprite LoadGame;
    public Sprite HowToPlay;
    public Sprite HighScores;
    public Sprite Quit;
    public Sprite Settings;
    public Sprite Pause;
    public Sprite Back;
    public Sprite UpgradeWeaponDualPistol;
    public Sprite UpgradeWeaponRifle;
    public Sprite UpgradeWeaponShotgun;
    public Sprite UpgradeSpeed;
    public Sprite UpgradeHealth;
    public Sprite UpgradeGetShield;
    public Sprite UpgradeShieldTopUp;
    public Sprite Medal;
    public Sprite HowToPlayImage;
    public Sprite Handle;
    public Sprite ToggleBoxEmpty;
    public Sprite CheckMark;
    public Sprite Trophy;

    // Player Prefabs
    public GameObject playerPistolPrefab;
    public GameObject playerDualPistolPrefab;
    public GameObject playerRiflePrefab;
    public GameObject playerShotgunPrefab;

    // Enemy Prefabs
    public GameObject enemyPrefabL1;
    public GameObject enemyPrefabL2;
    public GameObject enemyPrefabL3;
    public GameObject enemyPrefabL4;
    public GameObject enemyPrefabL5;
    public GameObject enemyPrefabL6;

    // Healthbar Prefabs
    public GameObject HealthBarPlayerPrefab;
    public GameObject ShieldBarPrefab;
    public GameObject HealthBarEnemyPrefab;
    
    // Fonts
    public Font shareTechMono;
    public Font chakraPetch;
    public Font Arial;

    // Enemy max health values per level
    public int enemyHealthL1 {get; private set;} = 100;
    public int enemyHealthL2 {get; private set;} = 200;
    public int enemyHealthL3 {get; private set;} = 300;
    public int enemyHealthL4 {get; private set;} = 400;
    public int enemyHealthL5 {get; private set;} = 400;
    public int enemyHealthL6 {get; private set;} = 400;

    // Enemy damage per bullet on each level
    public int enemyDamageL1 {get; private set;} = 5;
    public int enemyDamageL2 {get; private set;} = 6;
    public int enemyDamageL3 {get; private set;} = 6;
    public int enemyDamageL4 {get; private set;} = 7;
    public int enemyDamageL5 {get; private set;} = 7;
    public int enemyDamageL6 {get; private set;} = 7;

    // Weapon damage per bullet
    public int pistolDamage {get; private set;} = 5;
    public int dualPistolDamage {get; private set;} = 4;
    public int rifleDamage {get; private set;} = 7;
    public int shotgunDamage {get; private set;} = 5;
    
}
