using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class SSStoryText : MonoBehaviour
{
    private GameObject theStoryText;

    private float delay = 0.03f;
    private string fullText;
    private string currentText = "";

    private void Awake()
    {
        // create text gameobject
        theStoryText = new GameObject();
        theStoryText = ComponentMethods.createTextGO(theStoryText, "StoryText", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3(0f, 0f, 0f));
        theStoryText.GetComponent<RectTransform>().sizeDelta = new Vector2(AssetsHolder.getInstance().refSW - 256f, AssetsHolder.getInstance().refSH - 115f);
        theStoryText = ComponentMethods.setTextProperties(theStoryText, "", AssetsHolder.getInstance().shareTechMono,
                                                         FontStyle.Normal, 36, TextAnchor.UpperLeft, Color.green);
    }

    private void Start()
    {
        fullText = "Hello Commander... \n \n" + 
                    "The Corona Virus has run wild around the world. We thought we could control it, but we couldn't. \n \n" +
                    "These tough times call for tough people. We need you. We need you to eradicate this damn virus once and for all to save the world. Only you can defeat this thing now. \n \n" + 
                    "Your mission, should you choose to accept it, is to defeat the Corona Virus whichever way you can. \n \n" + 
                    "Press ENTER to accept this mission... ";
        
        StartCoroutine(ShowText());
    }

    private void Update()
    {
        // User presses enter to move to title screen
        if (Input.GetKeyUp(KeyCode.Return)) {
            SceneController.getInstance().LoadingScene("TitleScreen");
            // Debug.Log("Scene Load: TITLE SCREEN");
        }
    }

    private IEnumerator ShowText() 
    {
        // write the text one letter at a time
        for(int i = 0; i < fullText.Length; i++) {
            currentText = fullText.Substring(0,i);
            theStoryText.GetComponent<Text>().text = currentText;
            yield return new WaitForSeconds(delay);
        }
    }
}
