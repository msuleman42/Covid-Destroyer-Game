using UnityEngine;

public class StoryScreen : MonoBehaviour
{
    private static GameObject SSBackground;
    private static GameObject SSStoryText;

    private static GameObject currentView;

    private static void Init() {
        // Intialise the views to show/hide
        GameObject canvas = GameObject.Find("Canvas");

        SSStoryText = new GameObject();
        SSStoryText = ComponentMethods.createEmptyGO(SSStoryText, "Text", canvas, new Vector3 (1f, 1f, 1f),
                                                     new Vector3(0f, 0f, 0f), new Vector2(AssetsHolder.getInstance().refSW, AssetsHolder.getInstance().refSH));
        SSStoryText.AddComponent<SSStoryText>();
    }
    
    // private void Awake() 
    // {
    //     float screenHeight = Camera.main.orthographicSize*2;
    //     float screenWidth = (screenHeight / Screen.height) * Screen.width;

    //     Debug.Log("Height: " + screenHeight + "... Width: " + screenWidth);
    //     Debug.Log("Height: " + Screen.height + "... Width: " + Screen.width);
    // }
    
    private void Start()
    {
        // Set Background
        SSBackground = new GameObject();
        SSBackground = ComponentMethods.createSpriteGO(SSBackground, "Background", this.gameObject, "Background", new Vector3(100f, 100f, 1f), 
                                                        new Vector3(0f, 0f, 0f), new Vector2(AssetsHolder.getInstance().refSW, AssetsHolder.getInstance().refSH));
        SSBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().StoryScreenBackground;

        Init();
        
        HideAllViews();
        InitialView(SSStoryText);
    }

    // Hide all views in scene
    private void HideAllViews()
    {
        SSStoryText.SetActive(false);
        currentView = null;
    }

    private void InitialView(GameObject view)
    {
        // set initial view
        view.SetActive(true);
        currentView = view;
    }

}
