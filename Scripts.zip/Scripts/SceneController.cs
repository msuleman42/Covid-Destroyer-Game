using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneController : MonoBehaviour
{
    //singleton pattern
    static SceneController instance;

    public static SceneController getInstance() {
        return instance;
    }
    
    private AsyncOperation op;
    private Canvas canvas;
    private GameObject loadingPic;
    private GameObject loadingText;
    private GameObject loadingProgress;
    //private Image currentLoadingScreen;
    private string currentSceneName;

    [SerializeField]
    private Sprite[] loadingScreens;
    [SerializeField]
    private Font loadingFont;

    private void Awake() 
    {
        // singleton instancing
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }

        currentSceneName = SceneManager.GetActiveScene().name;
        // find the canvas inside the this gameObject and then set up the loading screens
        canvas = GetComponentInChildren<Canvas>(true);
        
        loadingPic = new GameObject();
        loadingPic = ComponentMethods.createImageGO(loadingPic, "LoadingPic", canvas.gameObject, new Vector3(1f, 1f, 1f), new Vector3(0f, 0f, 0f));
        loadingPic.GetComponent<Image>().sprite = loadingScreens[0];
        loadingPic.GetComponent<RectTransform>().sizeDelta = new Vector2(1280f, 720f);

        loadingText = new GameObject();
        loadingText = ComponentMethods.createTextGO(loadingText, "LoadingText", canvas.gameObject);
        loadingText = ComponentMethods.setPositionFromParent(loadingText, RectTransform.Edge.Bottom, 0f, 110f, RectTransform.Edge.Left, 20f, 500f);
        loadingText = ComponentMethods.setTextProperties(loadingText, "LOADING", loadingFont, FontStyle.Bold, 80, TextAnchor.MiddleLeft, Color.black);

        loadingProgress = new GameObject();
        loadingProgress = ComponentMethods.createTextGO(loadingProgress, "LoadingProgress", canvas.gameObject);
        loadingProgress.name = "LoadingProgress";
        loadingProgress = ComponentMethods.setPositionFromParent(loadingProgress, RectTransform.Edge.Bottom, 0f, 110f, RectTransform.Edge.Right, 20f, 250f);
        loadingProgress = ComponentMethods.setTextProperties(loadingProgress, "100%", loadingFont, FontStyle.Bold, 80, TextAnchor.MiddleRight, Color.black);

    }

    private void Start() 
    {
        // set canvas to false at the start. Only needed when loading
        canvas.gameObject.SetActive(false);
    }

    public void LoadingScene(string toLoadSceneName) 
    {
        // public as gets called to load a new scene from elsewhere
        setLoadingScreen(toLoadSceneName);

        setLoadingProgress(0);
        canvas.gameObject.SetActive(true);

        StartCoroutine(StartLoad(toLoadSceneName));
        currentSceneName = SceneManager.GetActiveScene().name;
        
        //canvas.gameObject.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceCamera;
        //canvas.worldCamera = Camera.main;
    }

    private void setLoadingScreen(string toLoadSceneName) 
    {
        // set the loading screen image depending on the current scene and the scene loading
        if (toLoadSceneName.Equals("TitleScreen") && currentSceneName.Equals("StoryScreen")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[0];
        }
        else if (toLoadSceneName.Equals("TitleScreen")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[7];
        }
        else if (toLoadSceneName.Equals("LevelOne")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[1];
        }
        else if (toLoadSceneName.Equals("LevelTwo")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[2];
        }
        else if (toLoadSceneName.Equals("LevelThree")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[3];
        }
        else if (toLoadSceneName.Equals("LevelFour")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[4];
        }
        else if (toLoadSceneName.Equals("LevelFive")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[5];
        }
        else if (toLoadSceneName.Equals("LevelSix")) {
            loadingPic.GetComponent<Image>().sprite = loadingScreens[6];
        }
    }

    private IEnumerator StartLoad(string sceneName)
    {
        // load the scene asynchronously and set the progress percentage
        op = SceneManager.LoadSceneAsync(sceneName);

        while(!op.isDone)
        {
            setLoadingProgress(op.progress);
            yield return null;
        }
        setLoadingProgress(op.progress);
        op = null;
        yield return new WaitForSeconds(1f);
        canvas.gameObject.SetActive(false);
    }

    private void setLoadingProgress(float progressPercentage)
    {
        // set the progress percentage text
        loadingProgress.GetComponent<Text>().text = (int)(progressPercentage * 100f) + "%";
    }
}
