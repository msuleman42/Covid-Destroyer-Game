using UnityEngine;

public class FireAtTarget : MonoBehaviour
{
    [SerializeField]
    private float direction; // 1 to shoot up (player), -1 to shoot down (enemy)
    [SerializeField]
    private float speed;
    [SerializeField]
    private Rigidbody2D rbBullet;

    private Transform player;
    private Vector2 target;

    void Start()
    {
        // get player game object
        player = GameObject.FindGameObjectsWithTag("Player")[0].transform;
        // set the target to be the current position of the player at time of instantiation
        target = (player.position - gameObject.transform.position).normalized * speed;
        // set velocity of bullet in direction of the target
        rbBullet.velocity = new Vector2(target.x, target.y);
    }

    void OnTriggerEnter2D (Collider2D col) 
    {
        // destroy this gameobject as long as the thing it collided with was not another bullet
        if (col.gameObject.tag != "Bullet" && col.gameObject.tag != "PlayerBullet") {
            //Debug.Log(col.name);
            Destroy(gameObject);
        }
        
        // if bullet hits enemy it was the player that instantiated that bullet, so +20points, 
        // else if the bullet hits the player, the enemy instatiated it, so -3points,
        // else if the bullet hits the top wall, the player instantiated the bullet so -1point
        if (col.gameObject.tag == "Enemy") {
            GameController.getInstance().AddScore(20);
        }
        else if (col.gameObject.tag == "Player") {
            GameController.getInstance().AddScore(-3);
        }
        else if (col.gameObject.tag == "TopWall") {
            GameController.getInstance().AddScore(-1);
        }
    }
}
