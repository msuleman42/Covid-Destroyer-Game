using UnityEngine;

public class AudioEnemyDead : MonoBehaviour
{
    [SerializeField]
    private AudioSource audioClick;

    private void OnEnable() 
    {
        // Play sound when Action invoked
        AudioController.enemyOnDeath += playSound;
    }

    private void OnDisable() {
        AudioController.enemyOnDeath -= playSound;
    }

    private void playSound() {
        audioClick.Play();
    }
}
