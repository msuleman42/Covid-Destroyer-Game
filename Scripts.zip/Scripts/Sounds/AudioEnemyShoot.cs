using UnityEngine;

public class AudioEnemyShoot : MonoBehaviour
{
    [SerializeField]
    private AudioSource audioClick;

    private void OnEnable() 
    {
        // Play sound when Action invoked
        AudioController.enemyOnShoot += playSound;
    }

    private void OnDisable() {
        AudioController.enemyOnShoot -= playSound;
    }

    private void playSound() {
        audioClick.Play();
    }
}
