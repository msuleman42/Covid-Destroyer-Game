using UnityEngine;

public class AudioMusic : MonoBehaviour
{
    [SerializeField]
    private AudioSource audioBackground;
    [SerializeField]
    private AudioSource audioInGame;
    
    private void OnEnable() 
    {
        // Play sound when Action invoked
        AudioController.inGameMusicChange += playSound;
    }

    private void OnDisable() {
        AudioController.inGameMusicChange -= playSound;
    }

    private void playSound(bool isInGame) {
        if (isInGame) {
            audioBackground.Stop();
            audioInGame.Play();
        }
        else {
            audioInGame.Stop();
            audioBackground.Play();
        }
    }
}
