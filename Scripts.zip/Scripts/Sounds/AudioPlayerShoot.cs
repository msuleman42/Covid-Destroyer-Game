using UnityEngine;

public class AudioPlayerShoot : MonoBehaviour
{
    [SerializeField]
    private AudioSource pistolSFX;
    [SerializeField]
    private AudioSource dualPistolSFX;
    [SerializeField]
    private AudioSource rifleSFX;
    [SerializeField]
    private AudioSource shotgunSFX;
    
    private void OnEnable() 
    {
        // Play sound when Action invoked
        AudioController.playerOnShoot += playSound;
    }

    private void OnDisable() {
        AudioController.playerOnShoot -= playSound;
    }

    private void playSound(WeaponsEnum weaponType) {
        // play sound depending on what the weapon is
        if (weaponType == WeaponsEnum.Pistol) {
            pistolSFX.Play();
        }
        else if (weaponType == WeaponsEnum.DualPistol) {
            dualPistolSFX.Play();
        }
        else if (weaponType == WeaponsEnum.Rifle) {
            rifleSFX.Play();
        }
        else {
            shotgunSFX.Play();
        }
    }
}
