using UnityEngine;

public class AudioPlayerDead : MonoBehaviour
{
    [SerializeField]
    private AudioSource audioClick;

    private void OnEnable() 
    {
        // Play sound when Action invoked
        AudioController.playerOnDeath += playSound;
    }

    private void OnDisable() {
        AudioController.playerOnDeath -= playSound;
    }

    private void playSound() {
        audioClick.Play();
    }
}
