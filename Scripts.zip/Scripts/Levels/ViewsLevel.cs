public enum ViewsLevel
{
    StartingView,
    GameView,
    EndingView,
    PauseView,
    GameOverView,
    QuitView,
    ReturnToMainMenuView
}
