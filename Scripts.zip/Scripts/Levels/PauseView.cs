using UnityEngine;
using UnityEngine.UI;

public class PauseView : MonoBehaviour
{
    private GameObject Back;
    private GameObject ResumeButton;
    private GameObject ResumeText;
    private GameObject ReturnToMainMenuButton;
    private GameObject ReturnToMainMenuText;
    private GameObject QuitButton;
    private GameObject QuitText;

    private Color viewBackgroundColor;

    private void Awake() 
    {
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);

        // Panel to hold other objects
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (490f, 305f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Resume Button to start the game
        ResumeButton = new GameObject();
        ResumeButton = ComponentMethods.createButtonGO(ResumeButton, "ResumeButton", Back);
        ResumeButton.GetComponent<Image>().color = Color.grey;
        ResumeButton.GetComponent<Button>().onClick.AddListener(OnClick_Resume);
        ResumeButton = ComponentMethods.setPositionFromParent(ResumeButton, RectTransform.Edge.Top, 20f, 75f, RectTransform.Edge.Left, 20f, 450f);

        ResumeText = new GameObject();
        ResumeText = ComponentMethods.createTextGO(ResumeText, "ResumeText", ResumeButton);
        ResumeText = ComponentMethods.setPositionFromParent(ResumeText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 450f);
        ResumeText = ComponentMethods.setTextProperties(ResumeText, "RESUME", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 35, TextAnchor.MiddleCenter, Color.black);

        // Return to Main Menu Button
        ReturnToMainMenuButton = new GameObject();
        ReturnToMainMenuButton = ComponentMethods.createButtonGO(ReturnToMainMenuButton, "ReturnButton", Back);
        ReturnToMainMenuButton.GetComponent<Image>().color = Color.grey;
        ReturnToMainMenuButton.GetComponent<Button>().onClick.AddListener(OnClick_ReturnToMainMenu);
        ReturnToMainMenuButton = ComponentMethods.setPositionFromParent(ReturnToMainMenuButton, RectTransform.Edge.Top, 115f, 75f, RectTransform.Edge.Left, 20f, 450f);

        ReturnToMainMenuText = new GameObject();
        ReturnToMainMenuText = ComponentMethods.createTextGO(ReturnToMainMenuText, "ReturnText", ReturnToMainMenuButton);
        ReturnToMainMenuText = ComponentMethods.setPositionFromParent(ReturnToMainMenuText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 450f);
        ReturnToMainMenuText = ComponentMethods.setTextProperties(ReturnToMainMenuText, "RETURN TO MAIN MENU", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 35, TextAnchor.MiddleCenter, Color.black);
        
        // Quit Button to start the game
        QuitButton = new GameObject();
        QuitButton = ComponentMethods.createButtonGO(QuitButton, "QuitButton", Back);
        QuitButton.GetComponent<Image>().color = Color.grey;
        QuitButton.GetComponent<Button>().onClick.AddListener(OnClick_Quit);
        QuitButton = ComponentMethods.setPositionFromParent(QuitButton, RectTransform.Edge.Top, 210f, 75f, RectTransform.Edge.Left, 20f, 450f);

        QuitText = new GameObject();
        QuitText = ComponentMethods.createTextGO(QuitText, "QuitText", QuitButton);
        QuitText = ComponentMethods.setPositionFromParent(QuitText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 450f);
        QuitText = ComponentMethods.setTextProperties(QuitText, "QUIT", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 35, TextAnchor.MiddleCenter, Color.black);

    }

    // Update is called once per frame
    void Update()
    {
        // escape key to unpause the game as well as the resume button
        if(Input.GetKeyDown(KeyCode.Escape)) {
            if(Levels.isPaused) {
                ResumeGame();
            }
        }
    }

    // On click methods --------------------------------------------------------------------------------
    private void OnClick_Resume() 
    {
        ResumeGame();
    }

    private void OnClick_ReturnToMainMenu() 
    {
        Levels.SwitchView(ViewsLevel.ReturnToMainMenuView);
        // Debug.Log("RETURN TO MAIN MENU");
    }

    private void OnClick_Quit() 
    {
        Levels.SwitchView(ViewsLevel.QuitView);
        // Debug.Log("QUIT GAME");
    }

    private void ResumeGame()
    {
        Levels.resumeGame();
        // Debug.Log("RESUME GAME");
    }
}
