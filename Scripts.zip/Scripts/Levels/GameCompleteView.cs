using UnityEngine;
using UnityEngine.UI;

public class GameCompleteView : MonoBehaviour
{
    private GameObject Back;
    private GameObject WinImage;
    private GameObject newHighScoreText;
    private GameObject finishedGameText;
    private GameObject ReturnToMainMenuButton;
    private GameObject ReturnToMainMenuText;
    private GameObject QuitButton;
    private GameObject QuitText;

    private Color viewBackgroundColor;

    private void Awake() {
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold other objects
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (500f, 670f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Medal image to show victory on completing the game
        WinImage = new GameObject();
        WinImage = ComponentMethods.createImageGO(WinImage, "WinImage", Back);
        WinImage.GetComponent<Image>().sprite = AssetsHolder.getInstance().Medal;
        WinImage.GetComponent<Image>().SetNativeSize();
        WinImage = ComponentMethods.setPositionFromParent(WinImage, RectTransform.Edge.Top, 30f, 196f, RectTransform.Edge.Left, 152f, 196f);

        // New High Score text only visible when player gets a high score
        newHighScoreText = new GameObject();
        newHighScoreText = ComponentMethods.createTextGO(newHighScoreText, "NewHighScoreText", Back);
        newHighScoreText = ComponentMethods.setPositionFromParent(newHighScoreText, RectTransform.Edge.Top, 230f, 30f, RectTransform.Edge.Left, 20f, 460f);
        newHighScoreText = ComponentMethods.setTextProperties(newHighScoreText, "NEW HIGH SCORE", 
                                                             AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 25, TextAnchor.MiddleCenter, Color.white);
        newHighScoreText.SetActive(false);

        // Text at the end of the game
        finishedGameText = new GameObject();
        finishedGameText = ComponentMethods.createTextGO(finishedGameText, "Text", Back);
        finishedGameText = ComponentMethods.setPositionFromParent(finishedGameText, RectTransform.Edge.Top, 260f, 210f, RectTransform.Edge.Left, 20f, 460f);
        finishedGameText = ComponentMethods.setTextProperties(finishedGameText, "",
                                                                AssetsHolder.getInstance().shareTechMono, FontStyle.Normal, 25, TextAnchor.MiddleCenter, Color.yellow);
        
        // Return to Main Menu Button
        ReturnToMainMenuButton = new GameObject();
        ReturnToMainMenuButton = ComponentMethods.createButtonGO(ReturnToMainMenuButton, "ReturnButton", Back);
        ReturnToMainMenuButton.GetComponent<Image>().color = Color.grey;
        ReturnToMainMenuButton.GetComponent<Button>().onClick.AddListener(OnClick_ReturnToMainMenu);
        ReturnToMainMenuButton = ComponentMethods.setPositionFromParent(ReturnToMainMenuButton, RectTransform.Edge.Bottom, 115f, 75f, RectTransform.Edge.Left, 25f, 450f);

        ReturnToMainMenuText = new GameObject();
        ReturnToMainMenuText = ComponentMethods.createTextGO(ReturnToMainMenuText, "ReturnText", ReturnToMainMenuButton);
        ReturnToMainMenuText = ComponentMethods.setPositionFromParent(ReturnToMainMenuText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 450f);
        ReturnToMainMenuText = ComponentMethods.setTextProperties(ReturnToMainMenuText, "RETURN TO MAIN MENU", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 35, TextAnchor.MiddleCenter, Color.black);
        
        // Quit Button to exit the game
        QuitButton = new GameObject();
        QuitButton = ComponentMethods.createButtonGO(QuitButton, "QuitButton", Back);
        QuitButton.GetComponent<Image>().color = Color.grey;
        QuitButton.GetComponent<Button>().onClick.AddListener(OnClick_Quit);
        QuitButton = ComponentMethods.setPositionFromParent(QuitButton, RectTransform.Edge.Bottom, 20f, 75f, RectTransform.Edge.Left, 25f, 450f);

        QuitText = new GameObject();
        QuitText = ComponentMethods.createTextGO(QuitText, "QuitText", QuitButton);
        QuitText = ComponentMethods.setPositionFromParent(QuitText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 450f);
        QuitText = ComponentMethods.setTextProperties(QuitText, "QUIT", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 35, TextAnchor.MiddleCenter, Color.black);
        
    }

    void OnEnable() 
    {
        if (GameController.getInstance().isHighScore()) {
            newHighScoreText.SetActive(true);
        }

        finishedGameText.GetComponent<Text>().text = "<size=50><b>CONGRATULATIONS!</b></size>\n" + 
                                                        "<color=black>You've defeated COVID and saved the world!\n" + 
                                                        "<size=50><b>SCORE: " + GameController.getInstance().score + "</b></size></color>";

        // Set the high score table/list and file
        if (GameController.getInstance().enemyDead && GameController.getInstance().levelNumber == LevelsEnum.LevelSix && GameController.getInstance().highScoreRecorded == false) {
            GameController.getInstance().addHighScore();
            GameController.getInstance().highScoreRecorded = true;
        }
    }

    // Onclick Button Methods --------------------------------------------------------------------------------------------------
    private void OnClick_ReturnToMainMenu() 
    {
        Levels.setTimeScale(1f);
        Levels.isPaused = false;
        // Delete game instance
        GameController.getInstance().DestroyInstance();
        SceneController.getInstance().LoadingScene("TitleScreen");
        // Debug.Log("Scene Load: TITLE SCREEN");
    }
    private void OnClick_Quit()
    {
        Levels.SwitchView(ViewsLevel.QuitView);
        // Debug.Log("QUIT GAME");
    }

}
