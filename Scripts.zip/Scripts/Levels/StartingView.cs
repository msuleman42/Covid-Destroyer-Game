using UnityEngine;
using UnityEngine.UI;

public class StartingView : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject LevelText;
    private GameObject StartButton;
    private GameObject StartText;

    private Color viewBackgroundColor;

    private void Awake()
    {        
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold other objects
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (850f, 500f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Level heading chosen depending on the level user is on
        Heading = new GameObject();
        Heading = ComponentMethods.createImageGO(Heading, "LevelHeading", Back);
        if (GameController.getInstance().levelNumber == LevelsEnum.LevelOne) {
            Heading.GetComponent<Image>().sprite = AssetsHolder.getInstance().LevelOneTitle;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelTwo) {
            Heading.GetComponent<Image>().sprite = AssetsHolder.getInstance().LevelTwoTitle;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelThree) {
            Heading.GetComponent<Image>().sprite = AssetsHolder.getInstance().LevelThreeTitle;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelFour) {
            Heading.GetComponent<Image>().sprite = AssetsHolder.getInstance().LevelFourTitle;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelFive) {
            Heading.GetComponent<Image>().sprite = AssetsHolder.getInstance().LevelFiveTitle;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelSix) {
            Heading.GetComponent<Image>().sprite = AssetsHolder.getInstance().LevelSixTitle;
        }
        Heading.GetComponent<Image>().SetNativeSize();
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 20f, 75f, RectTransform.Edge.Left, 50f, 750f);

        // Text chosen depending on what level user is on
        string textLevelOne = "Welcome to Europe, " + GameController.getInstance().playerName + "\n\n" +
                             "It's unfortunate your visit must be under such extreme circumstances. The Corona Virus is just starting to grow in Europe, " +
                             "so this is great place to start our attack. \n\n<b>Enemy Type:</b> B.1.1.7. \nNo movement detected. Patterned projectiles";
        string textLevelTwo = "Welcome to North America, " + GameController.getInstance().playerName + "\n\n" +
                             "COVID has been growing in America for some time now. Most people aren't listening to the advice to stay inside. Hopefully you can defeat " +
                             "this thing before it's too late. \n\n<b>Enemy Type:</b> B.1.1.7. \nMovement detected. Patterned projectiles";
        string textLevelThree = "Welcome to South America, " + GameController.getInstance().playerName + "\n\n" +
                             "A new variant of the virus has been detected. Not much is known about this variant besides the fact its movement patterns have shown to be erratic. " +
                             "Be careful out there. \n\n<b>Enemy Type:</b> P.1. \nRandom Movement. Patterned projectiles";
        string textLevelFour = "Welcome to Africa, " + GameController.getInstance().playerName + "\n\n" +
                             "Another variant of COVID has been detected in the southern parts of Africa. Its spreading fast and causing mass panic all over the continent. " +
                             "Put the people at ease and defeat this thing. \n\n<b>Enemy Type:</b> B.1.351. \nRandom movement. Random projectiles. <color=red>Rage Mode</color>";
        string textLevelFive = "Welcome to Oceania, " + GameController.getInstance().playerName + "\n\n" +
                             "Not much is known about the state of the Corona Virus in Australia. The people seem to be opperating as normal for now. But we aren't sure how " +
                             "it will respond to a direct attack. \n\n<b>Enemy Type:</b> B.1.617.2. \nMovements Unknown. <color=purple>Invincibility Mode</color>";
        string textLevelSix = "Welcome to Asia, " + GameController.getInstance().playerName + "\n\n" +
                             "The first reports of COVID were discovered in China and now the virus has evolved into something adaptable and far more dangerous." +
                             "This is the final hurdle. The fate of the world rests on your shoulders. \n<b>Enemy Type:</b> B.1.617.2. \nMovements Unknown";
        
        string textLevel = "";
        if (GameController.getInstance().levelNumber == LevelsEnum.LevelOne) {
            textLevel = textLevelOne;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelTwo) {
            textLevel = textLevelTwo;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelThree) {
            textLevel = textLevelThree;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelFour) {
            textLevel = textLevelFour;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelFive) {
            textLevel = textLevelFive;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelSix) {
            textLevel = textLevelSix;
        }

        LevelText = new GameObject();
        LevelText = ComponentMethods.createTextGO(LevelText, "LevelText", Back);
        LevelText = ComponentMethods.setPositionFromParent(LevelText, RectTransform.Edge.Top, 100f, 300f, RectTransform.Edge.Left, 60f, 730f);
        LevelText = ComponentMethods.setTextProperties(LevelText, textLevel, AssetsHolder.getInstance().shareTechMono, 
                                                        FontStyle.Normal, 28, TextAnchor.MiddleLeft, Color.black);

        // Start Button to start the game
        StartButton = new GameObject();
        StartButton = ComponentMethods.createButtonGO(StartButton, "StartButton", Back);
        StartButton.GetComponent<Image>().color = Color.grey;
        StartButton.GetComponent<Button>().onClick.AddListener(OnClick_Start);
        StartButton = ComponentMethods.setPositionFromParent(StartButton, RectTransform.Edge.Bottom, 25f, 50f, RectTransform.Edge.Left, 275f, 300f);

        StartText = new GameObject();
        StartText = ComponentMethods.createTextGO(StartText, "StartText", StartButton);
        StartText = ComponentMethods.setPositionFromParent(StartText, RectTransform.Edge.Top, 0f, 50f, RectTransform.Edge.Left, 0f, 300f);
        StartText = ComponentMethods.setTextProperties(StartText, "START", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 30, TextAnchor.MiddleCenter, Color.black);

    }

    private void Update()
    {
        // User presses enter to move to next view or presses the button
        if (Input.GetKeyUp(KeyCode.Return)) {
            PlayGame();
        }
    }

    // On click methods --------------------------------------------------------------------------------
    private void OnClick_Start() 
    {
        PlayGame();
    }

    private void PlayGame()
    {
        Levels.SwitchView(ViewsLevel.GameView);
        // Debug.Log("START LEVEL");
    }
}
