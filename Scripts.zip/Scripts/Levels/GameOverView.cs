using UnityEngine;
using UnityEngine.UI;

public class GameOverView : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject GameOverText;
    private GameObject newHighScoreText;
    private GameObject ReturnToMainMenuButton;
    private GameObject ReturnToMainMenuText;
    private GameObject QuitButton;
    private GameObject QuitText;

    private Color viewBackgroundColor;

    private void Awake()
    {        
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold other objects
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (490f, 575f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Level heading
        Heading = new GameObject();
        Heading = ComponentMethods.createImageGO(Heading, "GameOverHeading", Back);
        Heading.GetComponent<Image>().sprite = AssetsHolder.getInstance().GameOverTitle;
        Heading.GetComponent<Image>().SetNativeSize();
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 0f, 270f, RectTransform.Edge.Left, -25f, 540f);

        // Text
        //string textLevel = "<size=25>COVID wins!</size> \nFINAL SCORE: " + GameController.getInstance().score;
        GameOverText = new GameObject();
        GameOverText = ComponentMethods.createTextGO(GameOverText, "GameOverText", Back);
        GameOverText = ComponentMethods.setPositionFromParent(GameOverText, RectTransform.Edge.Top, 260f, 100f, RectTransform.Edge.Left, 20f, 450f);
        GameOverText = ComponentMethods.setTextProperties(GameOverText, "COVID Wins!", AssetsHolder.getInstance().shareTechMono, 
                                                        FontStyle.Bold, 40, TextAnchor.MiddleCenter, Color.black);

        // New High Score text only visible when player gets a high score
        newHighScoreText = new GameObject();
        newHighScoreText = ComponentMethods.createTextGO(newHighScoreText, "NewHighScoreText", Back);
        newHighScoreText = ComponentMethods.setPositionFromParent(newHighScoreText, RectTransform.Edge.Top, 360f, 30f, RectTransform.Edge.Left, 20f, 450f);
        newHighScoreText = ComponentMethods.setTextProperties(newHighScoreText, "NEW HIGH SCORE", 
                                                             AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 25, TextAnchor.MiddleCenter, Color.white);
        newHighScoreText.SetActive(false);

        // Return to Main Menu Button
        ReturnToMainMenuButton = new GameObject();
        ReturnToMainMenuButton = ComponentMethods.createButtonGO(ReturnToMainMenuButton, "ReturnButton", Back);
        ReturnToMainMenuButton.GetComponent<Image>().color = Color.grey;
        ReturnToMainMenuButton.GetComponent<Button>().onClick.AddListener(OnClick_ReturnToMainMenu);
        ReturnToMainMenuButton = ComponentMethods.setPositionFromParent(ReturnToMainMenuButton, RectTransform.Edge.Top, 395f, 75f, RectTransform.Edge.Left, 20f, 450f);

        ReturnToMainMenuText = new GameObject();
        ReturnToMainMenuText = ComponentMethods.createTextGO(ReturnToMainMenuText, "ReturnText", ReturnToMainMenuButton);
        ReturnToMainMenuText = ComponentMethods.setPositionFromParent(ReturnToMainMenuText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 450f);
        ReturnToMainMenuText = ComponentMethods.setTextProperties(ReturnToMainMenuText, "RETURN TO MAIN MENU", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 35, TextAnchor.MiddleCenter, Color.black);
        
        // Quit Button to exit the game
        QuitButton = new GameObject();
        QuitButton = ComponentMethods.createButtonGO(QuitButton, "QuitButton", Back);
        QuitButton.GetComponent<Image>().color = Color.grey;
        QuitButton.GetComponent<Button>().onClick.AddListener(OnClick_Quit);
        QuitButton = ComponentMethods.setPositionFromParent(QuitButton, RectTransform.Edge.Top, 480f, 75f, RectTransform.Edge.Left, 20f, 450f);

        QuitText = new GameObject();
        QuitText = ComponentMethods.createTextGO(QuitText, "QuitText", QuitButton);
        QuitText = ComponentMethods.setPositionFromParent(QuitText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 450f);
        QuitText = ComponentMethods.setTextProperties(QuitText, "QUIT", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 35, TextAnchor.MiddleCenter, Color.black);

    }

    void OnEnable() 
    {
        // Show "new high score" text if it is the highest score
        if (GameController.getInstance().isHighScore()) {
            newHighScoreText.SetActive(true);
        }
        // Set the game over text
        GameOverText.GetComponent<Text>().text = "<size=25>COVID Wins!</size> \nFINAL SCORE: " + GameController.getInstance().score;
        // To stop the high score being added multiple times if the view is enabled again
        // Set the high score table/list and file
        if (GameController.getInstance().playerDead && GameController.getInstance().highScoreRecorded == false) {
            GameController.getInstance().addHighScore();
            GameController.getInstance().highScoreRecorded = true;
        }
        
    }

    // On click methods --------------------------------------------------------------------------------
    private void OnClick_ReturnToMainMenu() 
    {
        Levels.setTimeScale(1f);
        Levels.isPaused = false;
        // Delete game instance
        GameController.getInstance().DestroyInstance();
        SceneController.getInstance().LoadingScene("TitleScreen");
        // Debug.Log("Scene Load: TITLE SCREEN");
    }
    private void OnClick_Quit()
    {
        Levels.SwitchView(ViewsLevel.QuitView);
        // Debug.Log("QUIT GAME");
    }
}
