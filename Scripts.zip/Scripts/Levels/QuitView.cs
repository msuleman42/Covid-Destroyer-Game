using UnityEngine;
using UnityEngine.UI;

public class QuitView : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject QuitMessage;
    private GameObject YesButton;
    private GameObject NoButton;
    private GameObject YesText;
    private GameObject NoText;

    private Color viewBackgroundColor;

    private void Awake()
    {        
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold the input field and button
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3(1f, 1f, 1f), new Vector3(0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (600f, 250f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Quit heading
        Heading = new GameObject();
        Heading = ComponentMethods.createTextGO(Heading, "Quit", Back);
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 0f, 90f, RectTransform.Edge.Left, 0f, 600f);
        Heading = ComponentMethods.setTextProperties(Heading, "QUIT", AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 80, TextAnchor.MiddleCenter, Color.black);

        // Quit message
        QuitMessage = new GameObject();
        QuitMessage = ComponentMethods.createTextGO(QuitMessage, "QuitMessage", Back);
        QuitMessage = ComponentMethods.setPositionFromParent(QuitMessage, RectTransform.Edge.Top, 90f, 75f, RectTransform.Edge.Left, 0f, 600f);
        QuitMessage = ComponentMethods.setTextProperties(QuitMessage, "Are you sure you would like to quit the application? \nProgress for this level may be lost.", 
                                                        AssetsHolder.getInstance().Arial, FontStyle.Normal, 24, TextAnchor.MiddleCenter, Color.black);

        // Yes button to exit game to main title screen
        YesButton = new GameObject();
        YesButton = ComponentMethods.createButtonGO(YesButton, "YesButton", Back);
        YesButton.GetComponent<Image>().color = Color.grey;
        YesButton.GetComponent<Button>().onClick.AddListener(OnClick_Yes);
        YesButton = ComponentMethods.setPositionFromParent(YesButton, RectTransform.Edge.Top, 170f, 50f, RectTransform.Edge.Left, 100f, 150f);

        YesText = new GameObject();
        YesText = ComponentMethods.createTextGO(YesText, "YesText", YesButton);
        YesText = ComponentMethods.setPositionFromParent(YesText, RectTransform.Edge.Top, 0f, 50f, RectTransform.Edge.Left, 0f, 150f);
        YesText = ComponentMethods.setTextProperties(YesText, "YES", AssetsHolder.getInstance().Arial, FontStyle.Normal, 30, TextAnchor.MiddleCenter, Color.black);

        // No Button to return to main title screen
        NoButton = new GameObject();
        NoButton = ComponentMethods.createButtonGO(NoButton, "NoButton", Back);
        NoButton.GetComponent<Image>().color = Color.grey;
        NoButton.GetComponent<Button>().onClick.AddListener(OnClick_No);
        NoButton = ComponentMethods.setPositionFromParent(NoButton, RectTransform.Edge.Top, 170f, 50f, RectTransform.Edge.Right, 100f, 150f);

        NoText = new GameObject();
        NoText = ComponentMethods.createTextGO(NoText, "NoText", NoButton);
        NoText = ComponentMethods.setPositionFromParent(NoText, RectTransform.Edge.Top, 0f, 50f, RectTransform.Edge.Left, 0f, 150f);
        NoText = ComponentMethods.setTextProperties(NoText, "NO", AssetsHolder.getInstance().Arial, FontStyle.Normal, 30, TextAnchor.MiddleCenter, Color.black);
    }

    // Button On Click Methods ------------------------------------------------------------------------------------------
    private void OnClick_Yes()
    {
        // set time to 1f again
        Levels.setTimeScale(1f);
        Levels.isPaused = false;
        Application.Quit();
        // Debug.Log("QUIT");
    }

    private void OnClick_No()
    {
        Levels.ReturnToPreviousView();
        // Debug.Log("RETURN");
    }
}
