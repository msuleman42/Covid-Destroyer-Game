using UnityEngine;

public class Levels : MonoBehaviour
{
    private static GameObject LevelBackground;
    private static GameObject LevelStartingView;
    private static GameObject LevelGameView;
    private static GameObject LevelEndingView;
    private static GameObject LevelPauseView;
    private static GameObject LevelGameOverView;
    private static GameObject LevelQuitView;
    private static GameObject LevelReturnToMainMenuView;

    private static GameObject currentView;
    private static GameObject previousView;
    private static ViewsLevel currentViewName;
    private static ViewsLevel previousViewName;
    public static bool isPaused = false;

    // private void Awake()
    // {
    //     float screenHeight = Camera.main.orthographicSize*2;
    //     float screenWidth = (screenHeight / Screen.height) * Screen.width;

    //     Debug.Log("Height: " + screenHeight + "... Width: " + screenWidth);
    //     Debug.Log("Height: " + Screen.height + "... Width: " + Screen.width);

    // }
    
    private static void Init() 
    {
        // Making sure the player or enemy are not set to dead
        GameController.getInstance().playerDead = false;
        GameController.getInstance().enemyDead = false;

        float screenWidth = AssetsHolder.getInstance().refSW;
        float screenHeight = AssetsHolder.getInstance().refSH;

        // set up the views
        GameObject canvas = GameObject.Find("Canvas");

        LevelStartingView = new GameObject();
        LevelStartingView = ComponentMethods.createEmptyGO(LevelStartingView, "StartingView", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                new Vector2(screenWidth, screenHeight));
        LevelStartingView.AddComponent<StartingView>();
        
        LevelGameView = new GameObject();
        LevelGameView = ComponentMethods.createEmptyGO(LevelGameView, "GameView", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                    new Vector2(screenWidth, screenHeight));
        LevelGameView.AddComponent<GameView>();

        LevelEndingView = new GameObject();
        LevelEndingView = ComponentMethods.createEmptyGO(LevelEndingView, "EndingView", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                new Vector2(screenWidth, screenHeight));
        if (GameController.getInstance().levelNumber == LevelsEnum.LevelSix) {
            LevelEndingView.AddComponent<GameCompleteView>();
        }
        else {
            LevelEndingView.AddComponent<EndingView>();
        }

        LevelPauseView = new GameObject();
        LevelPauseView = ComponentMethods.createEmptyGO(LevelPauseView, "PauseView", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                     new Vector2(screenWidth, screenHeight));
        LevelPauseView.AddComponent<PauseView>();

        LevelGameOverView = new GameObject();
        LevelGameOverView = ComponentMethods.createEmptyGO(LevelGameOverView, "GameOverView", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                         new Vector2(screenWidth, screenHeight));
        LevelGameOverView.AddComponent<GameOverView>();

        LevelQuitView = new GameObject();
        LevelQuitView = ComponentMethods.createEmptyGO(LevelQuitView, "QuitView", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                             new Vector2(screenWidth, screenHeight));
        LevelQuitView.AddComponent<QuitView>();

        LevelReturnToMainMenuView = new GameObject();
        LevelReturnToMainMenuView = ComponentMethods.createEmptyGO(LevelReturnToMainMenuView, "ReturnToMainMenuView", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                             new Vector2(screenWidth, screenHeight));
        LevelReturnToMainMenuView.AddComponent<ReturnToMainMenuView>();

    }

    private void Start()
    {
        // set up background and views
        LevelBackground = new GameObject();
        LevelBackground = ComponentMethods.createSpriteGO(LevelBackground, "Background", this.gameObject, "Background", new Vector3(100f, 100f, 1f), 
                                                        new Vector3(0f, 0f, 0f), new Vector2(AssetsHolder.getInstance().refSW, AssetsHolder.getInstance().refSH));
        if (GameController.getInstance().levelNumber == LevelsEnum.LevelOne) {
            LevelBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().LevelOneBackground;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelTwo) {
            LevelBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().LevelTwoBackground;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelThree) {
            LevelBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().LevelThreeBackground;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelFour) {
            LevelBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().LevelFourBackground;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelFive) {
            LevelBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().LevelFiveBackground;
        }
        else if (GameController.getInstance().levelNumber == LevelsEnum.LevelSix) {
            LevelBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().LevelSixBackground;
        }
        
        Init();
        
        HideAllViews();
        InitialView(LevelStartingView, ViewsLevel.StartingView);
    }

    // Hide all views in scene
    private void HideAllViews()
    {
        LevelStartingView.SetActive(false);
        LevelGameView.SetActive(false);
        LevelEndingView.SetActive(false);
        LevelPauseView.SetActive(false);
        LevelGameOverView.SetActive(false);
        LevelQuitView.SetActive(false);
        LevelReturnToMainMenuView.SetActive(false);
        currentView = null;
        previousView = null;
    }

    private void InitialView(GameObject view, ViewsLevel viewName)
    {
        // set initial view
        view.SetActive(true);
        currentView = view;
        currentViewName = viewName;
    }

    public static void SwitchView(ViewsLevel view)
    {
        // Gets called when views are switched
        previousViewName = currentViewName;
        previousView = currentView;
        currentView.SetActive(false);
        switch (view)
        {
            case ViewsLevel.StartingView:
                LevelStartingView.SetActive(true);
                currentView = LevelStartingView;
                currentViewName = ViewsLevel.StartingView;
            break;
            case ViewsLevel.GameView:
                // Game view only called from the starting view and the pause view. From pause view the resumeGame()
                // and pauseGame() methods are used. From the starting view to the game view this is called. From the
                // gameview to the ending view or gameover view, the game is finished so view can be deactivated.
                if(currentViewName == ViewsLevel.StartingView)
                {
                    LevelGameView.SetActive(true);
                    currentView = LevelGameView;
                    currentViewName = ViewsLevel.GameView;
                }
            break;
            case ViewsLevel.EndingView:
                LevelEndingView.SetActive(true);
                currentView = LevelEndingView;
                currentViewName = ViewsLevel.EndingView;
            break;
            case ViewsLevel.PauseView:
                LevelPauseView.SetActive(true);
                currentView = LevelPauseView;
                currentViewName = ViewsLevel.PauseView;
            break;
            case ViewsLevel.GameOverView:
                LevelGameOverView.SetActive(true);
                currentView = LevelGameOverView;
                currentViewName = ViewsLevel.GameOverView;
            break;
            case ViewsLevel.QuitView:
                LevelQuitView.SetActive(true);
                currentView = LevelQuitView;
                currentViewName = ViewsLevel.QuitView;
            break;
            case ViewsLevel.ReturnToMainMenuView:
                LevelReturnToMainMenuView.SetActive(true);
                currentView = LevelReturnToMainMenuView;
                currentViewName = ViewsLevel.ReturnToMainMenuView;
            break;
        }
    }

    public static void ReturnToPreviousView() {
        currentView.SetActive(false);
        currentView = previousView;
        currentView.SetActive(true);
    }

    public static void pauseGame()
    {
        LevelPauseView.SetActive(true);
        setTimeScale(0f);
        isPaused = true;
        currentView = LevelPauseView;
        currentViewName = ViewsLevel.PauseView;
    }

    public static void resumeGame()
    {
        LevelPauseView.SetActive(false);
        setTimeScale(1f);
        isPaused = false;
        currentView = LevelGameView;
        currentViewName = ViewsLevel.GameView;
    }

    public static void setTimeScale(float tScale)
    {
        Time.timeScale = tScale;
    }
}
