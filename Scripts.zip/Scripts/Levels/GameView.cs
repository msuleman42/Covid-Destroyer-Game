using UnityEngine;
using UnityEngine.UI;

public class GameView : MonoBehaviour
{
    private GameObject topCollider;
    private GameObject bottomCollider;
    private GameObject leftCollider;
    private GameObject rightCollider;
    private GameObject PEHolder;
    private GameObject player;
    private GameObject enemy;
    private GameObject playerHealthBar;
    private GameObject playerShieldBar;
    private GameObject enemyHealthBar;
    private GameObject playerHealthValue;
    private GameObject playerShieldValue;
    private GameObject enemyHealthValue;
    private GameObject HUD;
    private GameObject pauseButton;
    private GameObject scoreBackground;
    private GameObject scoreText;

    private float wallThickness = 50f;

    private void Awake()
    {
        // Making the walls
        topCollider = new GameObject();
        topCollider = ComponentMethods.createBoxColliderGO(topCollider, "TopWall", this.gameObject, new Vector2(AssetsHolder.getInstance().refSW, wallThickness));
        topCollider.tag = "TopWall";
        topCollider = ComponentMethods.setPositionFromParent(topCollider, RectTransform.Edge.Top, -wallThickness, wallThickness, 
                                                             RectTransform.Edge.Left, 0f, AssetsHolder.getInstance().refSW);

        bottomCollider = new GameObject();
        bottomCollider = ComponentMethods.createBoxColliderGO(bottomCollider, "BottomWall", this.gameObject, new Vector2(AssetsHolder.getInstance().refSW, wallThickness));
        bottomCollider = ComponentMethods.setPositionFromParent(bottomCollider, RectTransform.Edge.Bottom, -wallThickness, wallThickness, 
                                                                 RectTransform.Edge.Left, 0f, AssetsHolder.getInstance().refSW);

        leftCollider = new GameObject();
        leftCollider = ComponentMethods.createBoxColliderGO(leftCollider, "LeftWall", this.gameObject, new Vector2(wallThickness, AssetsHolder.getInstance().refSH));
        leftCollider.tag = "Wall";
        leftCollider = ComponentMethods.setPositionFromParent(leftCollider, RectTransform.Edge.Left, 140f, wallThickness, 
                                                                RectTransform.Edge.Top, 0f, AssetsHolder.getInstance().refSH);

        rightCollider = new GameObject();
        rightCollider = ComponentMethods.createBoxColliderGO(rightCollider, "RightWall", this.gameObject, new Vector2(wallThickness, AssetsHolder.getInstance().refSH));
        rightCollider.tag = "Wall";
        rightCollider = ComponentMethods.setPositionFromParent(rightCollider, RectTransform.Edge.Right, 140f, wallThickness, 
                                                                RectTransform.Edge.Top, 0f, AssetsHolder.getInstance().refSH);
        
        float canvasSF = AssetsHolder.getInstance().canvasScaleFactor;
        // Object to hold the Player and enemy
        PEHolder = new GameObject();
        PEHolder = ComponentMethods.createEmptyGO(PEHolder, "Player&Enemy", this.gameObject, new Vector3 (canvasSF, canvasSF, canvasSF), new Vector3 (0f, 0f, 0f), 
                                                    new Vector2(AssetsHolder.getInstance().refSW/canvasSF, AssetsHolder.getInstance().refSH/canvasSF));
        
        // Player spawned in
        player = instPlayer(GameController.getInstance().weaponType);
        player.transform.SetParent(PEHolder.transform);
        player.transform.localScale = new Vector3(1f, 1f, 1f);
        player.transform.localPosition = new Vector3 (0f, -280f/canvasSF, 0f);

        // Enemy spawned in 
        enemy = instEnemy(GameController.getInstance().levelNumber);
        enemy.transform.SetParent(PEHolder.transform);
        enemy.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
        enemy.transform.localPosition = new Vector3(0f, 288f/canvasSF, 0f);

        // Object to hold the health bars, score text and pause button (HUD)
        HUD = new GameObject();
        HUD = ComponentMethods.createEmptyGO(HUD, "HUD", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                    new Vector2(AssetsHolder.getInstance().refSW, AssetsHolder.getInstance().refSH));
        
        // Player Healthbar/Shieldbar
        playerHealthBar = Instantiate(AssetsHolder.getInstance().HealthBarPlayerPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity);
        playerHealthBar.transform.SetParent(HUD.transform);
        playerHealthBar.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        playerHealthBar.transform.localPosition = new Vector3(-600f, -150f, 0f); 
        playerHealthValue = new GameObject();
        playerHealthValue = ComponentMethods.createTextGO(playerHealthValue, "PlayerHealthValue", HUD);
        playerHealthValue = ComponentMethods.setPositionFromParent(playerHealthValue, RectTransform.Edge.Left, 15f, 50f, RectTransform.Edge.Top, 330f, 30f);
        playerHealthValue = ComponentMethods.setTextProperties(playerHealthValue, GameController.getInstance().health.ToString(), 
                                                                AssetsHolder.getInstance().shareTechMono, FontStyle.Normal, 25, TextAnchor.MiddleCenter, Color.green);

        if (GameController.getInstance().hasShield)
        {
            playerShieldBar = Instantiate(AssetsHolder.getInstance().ShieldBarPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity);
            playerShieldBar.transform.SetParent(HUD.transform);
            playerShieldBar.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
            playerShieldBar.transform.localPosition = new Vector3(-530f, -150f, 0f);
            playerShieldValue = new GameObject();
            playerShieldValue = ComponentMethods.createTextGO(playerShieldValue, "PlayerHealthValue", HUD);
            playerShieldValue = ComponentMethods.setPositionFromParent(playerShieldValue, RectTransform.Edge.Left, 85f, 50f, RectTransform.Edge.Top, 330f, 30f);
            playerShieldValue = ComponentMethods.setTextProperties(playerShieldValue, GameController.getInstance().shield.ToString(), 
                                                                AssetsHolder.getInstance().shareTechMono, FontStyle.Normal, 25, TextAnchor.MiddleCenter, Color.green);

        }

        // Enemy Healthbar
        enemyHealthBar = Instantiate(AssetsHolder.getInstance().HealthBarEnemyPrefab, new Vector3(0f, 0f, 0f), Quaternion.Euler(0f, 0f, 180f));
        enemyHealthBar.transform.SetParent(HUD.transform);
        enemyHealthBar.transform.localScale = new Vector3(0.75f, 0.75f, 0.75f);
        enemyHealthBar.transform.localPosition = new Vector3(600f, 150f, 0f);
        enemyHealthValue = new GameObject();
        enemyHealthValue = ComponentMethods.createTextGO(enemyHealthValue, "PlayerHealthValue", HUD);
        enemyHealthValue = ComponentMethods.setPositionFromParent(enemyHealthValue, RectTransform.Edge.Right, 15f, 50f, RectTransform.Edge.Bottom, 330f, 30f);
        enemyHealthValue = ComponentMethods.setTextProperties(enemyHealthValue, GameController.getInstance().enemyHealth.ToString(),
                                                                AssetsHolder.getInstance().shareTechMono, FontStyle.Normal, 25, TextAnchor.MiddleCenter, Color.green);

        // Pause button creation and position
        pauseButton = new GameObject();
        pauseButton = ComponentMethods.createButtonGO(pauseButton, "PauseButton", HUD);
        pauseButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().Pause;
        pauseButton.GetComponent<Image>().SetNativeSize();
        pauseButton.GetComponent<Button>().onClick.AddListener(OnClick_Pause);
        pauseButton = ComponentMethods.setPositionFromParent(pauseButton, RectTransform.Edge.Top, 10f, 50f, RectTransform.Edge.Left, 10f, 50f);

        // Score background and text creation and position
        scoreBackground = new GameObject();
        scoreBackground = ComponentMethods.createImageGO(scoreBackground, "ScoreBackground", HUD);
        scoreBackground.GetComponent<Image>().color = Color.black;
        scoreBackground = ComponentMethods.setPositionFromParent(scoreBackground, RectTransform.Edge.Bottom, 0f, 32f, RectTransform.Edge.Right, 0f, 170f);
        scoreText = new GameObject();
        scoreText = ComponentMethods.createTextGO(scoreText, "ScoreText", scoreBackground);
        scoreText = ComponentMethods.setPositionFromParent(scoreText, RectTransform.Edge.Bottom, 0f, 32f, RectTransform.Edge.Right, 0f, 170f);
        scoreText = ComponentMethods.setTextProperties(scoreText, "SCORE: " + GameController.getInstance().score, AssetsHolder.getInstance().shareTechMono,
                                                        FontStyle.Normal, 25, TextAnchor.MiddleCenter, Color.green);

    }

    void Start()
    {
        // Play ingame music
        AudioController.getInstance().changeBackgroundMusic(true);
    }

    // Update is called once per frame
    void Update()
    {
        // Change score text and health/shield text on each update
        scoreText.GetComponent<Text>().text = "SCORE: " + GameController.getInstance().score;
        playerHealthValue.GetComponent<Text>().text = GameController.getInstance().health.ToString();
        enemyHealthValue.GetComponent<Text>().text = GameController.getInstance().enemyHealth.ToString();
        if (GameController.getInstance().hasShield) {
            playerShieldValue.GetComponent<Text>().text = GameController.getInstance().shield.ToString();
        }

        // Escape key to pause the game as well as the button
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            if(Levels.isPaused == false){
                PauseGame();
            }
        }
        
        // if player dies, set the high score list and delete the player file so it can no longer be loaded
        if(GameController.getInstance().playerDead) {
            GameController.getInstance().DeletePlayerFile();
            Levels.SwitchView(ViewsLevel.GameOverView);
        }
        // if enemy dies and its not level 6 load the level complete view
        if(GameController.getInstance().enemyDead && GameController.getInstance().levelNumber != LevelsEnum.LevelSix) {
            Levels.SwitchView(ViewsLevel.EndingView);
        }
        // if enemy dies and the level is 6, set the high score list and delete the player file so it can no longer be loaded
        if(GameController.getInstance().enemyDead && GameController.getInstance().levelNumber == LevelsEnum.LevelSix) {
            GameController.getInstance().DeletePlayerFile();
            Levels.SwitchView(ViewsLevel.EndingView);
        }
    }

    void OnDisable()
    {
        // play not in game music when view is disabled
        AudioController.getInstance().changeBackgroundMusic(false);
    }

    // Functional Methods
    private GameObject instPlayer(WeaponsEnum weaponType)
    {
        // Instantiate player prefab based on the weapon the user has
        if (weaponType == WeaponsEnum.DualPistol) {
            return Instantiate(AssetsHolder.getInstance().playerDualPistolPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else if (weaponType == WeaponsEnum.Rifle) {
            return Instantiate(AssetsHolder.getInstance().playerRiflePrefab, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else if (weaponType == WeaponsEnum.Shotgun) {
            return Instantiate(AssetsHolder.getInstance().playerShotgunPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else {
            return Instantiate(AssetsHolder.getInstance().playerPistolPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
    }

    private GameObject instEnemy(LevelsEnum levelNumber) 
    {
        // Instantiate enemy based on the level the user is on
        if (levelNumber == LevelsEnum.LevelTwo) {
            return Instantiate(AssetsHolder.getInstance().enemyPrefabL2, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else if (levelNumber == LevelsEnum.LevelThree) {
            return Instantiate(AssetsHolder.getInstance().enemyPrefabL3, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else if (levelNumber == LevelsEnum.LevelFour) {
            return Instantiate(AssetsHolder.getInstance().enemyPrefabL4, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else if (levelNumber == LevelsEnum.LevelFive) {
            return Instantiate(AssetsHolder.getInstance().enemyPrefabL5, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else if (levelNumber == LevelsEnum.LevelSix) {
            return Instantiate(AssetsHolder.getInstance().enemyPrefabL6, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
        else {
            return Instantiate(AssetsHolder.getInstance().enemyPrefabL1, new Vector3(0f, 0f, 0f), Quaternion.identity);
        }
    }


    // Button on click methods ------------------------------------------------------------------------------------
    private void OnClick_Pause() 
    {
        if(Levels.isPaused == false)
        {
            PauseGame();
        } 
    }

    private void PauseGame()
    {
        Levels.pauseGame();
        // Debug.Log("PAUSE GAME");
    }
}
