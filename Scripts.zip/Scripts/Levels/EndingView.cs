using System;
using UnityEngine;
using UnityEngine.UI;

public class EndingView : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject upgradeText;
    private GameObject upgradeWeaponButton;
    private GameObject upgradeSpeedButton;
    private GameObject upgradeHealthButton;
    private GameObject upgradeShieldButton;
    private GameObject noUpgradeButton;
    private GameObject noUpgradeText;

    private Color viewBackgroundColor;

    private void Awake() {
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold other objects
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (1000f, 670f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Level heading
        string levelCompleteText = setLevelCompleteText(GameController.getInstance().levelNumber);
        Heading = new GameObject();
        Heading = ComponentMethods.createTextGO(Heading, "LevelCompleteHeading", Back);
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 20f, 90f, RectTransform.Edge.Left, 0f, 1000f);
        Heading = ComponentMethods.setTextProperties(Heading, levelCompleteText, 
                                                     AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 80, TextAnchor.MiddleCenter, Color.black);

        // Text below heading
        upgradeText = new GameObject();
        upgradeText = ComponentMethods.createTextGO(upgradeText, "Text", Back);
        upgradeText = ComponentMethods.setPositionFromParent(upgradeText, RectTransform.Edge.Top, 110f, 130f, RectTransform.Edge.Left, 20f, 960f);
        upgradeText = ComponentMethods.setTextProperties(upgradeText, "<b>Well done " + GameController.getInstance().playerName + "!</b> But the virus will be back. \n" + 
                                                        "Our team have been working hard to give you a fighting chance. \n<b><size=50>Choose one upgrade:</size></b>", 
                                                        AssetsHolder.getInstance().shareTechMono, FontStyle.Normal, 24, TextAnchor.MiddleCenter, Color.black);
        
        // Upgrade Weapon button
        upgradeWeaponButton = new GameObject();
        upgradeWeaponButton = ComponentMethods.createButtonGO(upgradeWeaponButton, "UpgradeWeaponButton", Back);
        setWeaponImage(upgradeWeaponButton);
        upgradeWeaponButton = ComponentMethods.setPositionFromParent(upgradeWeaponButton, RectTransform.Edge.Bottom, 115f, 300f, RectTransform.Edge.Left, 20f, 225f);

        // Upgrade speed button to increase movement speed
        upgradeSpeedButton = new GameObject();
        upgradeSpeedButton = ComponentMethods.createButtonGO(upgradeSpeedButton, "UpgradeSpeedButton", Back);
        upgradeSpeedButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().UpgradeSpeed;
        upgradeSpeedButton.GetComponent<Button>().onClick.AddListener(OnClick_UpgradeSpeed);
        upgradeSpeedButton = ComponentMethods.setPositionFromParent(upgradeSpeedButton, RectTransform.Edge.Bottom, 115f, 300f, RectTransform.Edge.Left, 265f, 225f);

        // Upgrade health button to increase max health
        upgradeHealthButton = new GameObject();
        upgradeHealthButton = ComponentMethods.createButtonGO(upgradeHealthButton, "UpgradeHealthButton", Back);
        upgradeHealthButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().UpgradeHealth;
        upgradeHealthButton.GetComponent<Button>().onClick.AddListener(OnClick_UpgradeHealth);
        upgradeHealthButton = ComponentMethods.setPositionFromParent(upgradeHealthButton, RectTransform.Edge.Bottom, 115f, 300f, RectTransform.Edge.Left, 510f, 225f);

        // Upgrade Shiled button either to get shield or to top up the shield
        upgradeShieldButton = new GameObject();
        upgradeShieldButton = ComponentMethods.createButtonGO(upgradeShieldButton, "UpgradeShieldButton", Back);
        setShieldImage(upgradeShieldButton);
        upgradeShieldButton.GetComponent<Button>().onClick.AddListener(OnClick_UpgradeShield);
        upgradeShieldButton = ComponentMethods.setPositionFromParent(upgradeShieldButton, RectTransform.Edge.Bottom, 115f, 300f, RectTransform.Edge.Left, 755f, 225f);

        // No upgrade button and text
        noUpgradeButton = new GameObject();
        noUpgradeButton = ComponentMethods.createButtonGO(noUpgradeButton, "NoUpgradeButton", Back);
        noUpgradeButton.GetComponent<Image>().color = Color.grey;
        noUpgradeButton.GetComponent<Button>().onClick.AddListener(OnClick_NoUpgrade);
        noUpgradeButton = ComponentMethods.setPositionFromParent(noUpgradeButton, RectTransform.Edge.Bottom, 20f, 75f, RectTransform.Edge.Left, 20f, 960f);

        noUpgradeText = new GameObject();
        noUpgradeText = ComponentMethods.createTextGO(noUpgradeText, "NoUpgradeText", noUpgradeButton);
        noUpgradeText = ComponentMethods.setPositionFromParent(noUpgradeText, RectTransform.Edge.Top, 0f, 75f, RectTransform.Edge.Left, 0f, 960f);
        noUpgradeText = ComponentMethods.setTextProperties(noUpgradeText, "NO UPGRADE", AssetsHolder.getInstance().chakraPetch, 
                                                        FontStyle.Normal, 40, TextAnchor.MiddleCenter, Color.black);
        
    }

    // Set the heading text based on the level
    private string setLevelCompleteText(LevelsEnum levelNumber) {
        if (levelNumber == LevelsEnum.LevelOne) {
            return "LEVEL 1 COMPLETE";
        }
        else if (levelNumber == LevelsEnum.LevelTwo) {
            return "LEVEL 2 COMPLETE";
        }
        else if (levelNumber == LevelsEnum.LevelThree) {
            return "LEVEL 3 COMPLETE";
        }
        else if (levelNumber == LevelsEnum.LevelFour) {
            return "LEVEL 4 COMPLETE";
        }
        else if (levelNumber == LevelsEnum.LevelFive) {
            return "LEVEL 5 COMPLETE";
        }
        else {
            return "";
        }
    }

    // Set the images on the buttons depending on the current player status
    private void setShieldImage(GameObject go)
    {
        if(GameController.getInstance().hasShield) {
            go.GetComponent<Image>().sprite = AssetsHolder.getInstance().UpgradeShieldTopUp;
        }
        else {
            go.GetComponent<Image>().sprite = AssetsHolder.getInstance().UpgradeGetShield;
        }

    }
    private void setWeaponImage(GameObject go)
    {
        if(GameController.getInstance().weaponType == WeaponsEnum.Pistol) {
            go.GetComponent<Image>().sprite = AssetsHolder.getInstance().UpgradeWeaponDualPistol;
            go.GetComponent<Image>().SetNativeSize();
            go.GetComponent<Button>().onClick.AddListener(OnClick_UpgradeWeapon);
        }
        else if (GameController.getInstance().weaponType == WeaponsEnum.DualPistol) {
            go.GetComponent<Image>().sprite = AssetsHolder.getInstance().UpgradeWeaponRifle;
            go.GetComponent<Image>().SetNativeSize();
            go.GetComponent<Button>().onClick.AddListener(OnClick_UpgradeWeapon);
        }
        else if (GameController.getInstance().weaponType == WeaponsEnum.Rifle) {
            go.GetComponent<Image>().sprite = AssetsHolder.getInstance().UpgradeWeaponShotgun;
            go.GetComponent<Image>().SetNativeSize();
            go.GetComponent<Button>().onClick.AddListener(OnClick_UpgradeWeapon);
        }
        else {
            go.GetComponent<Image>().color = Color.grey;
        }
    }

    private void advanceToNextLevel() {
        ResetTime();
        // Once upgrade is chosen, need to change some data, save it and advance to the next level
        GameController.getInstance().enemyDead = false;
        LevelsEnum currentLevel = GameController.getInstance().levelNumber;
        if (currentLevel == LevelsEnum.LevelOne) {
            GameController.getInstance().levelNumber = LevelsEnum.LevelTwo;
            GameController.getInstance().SaveGame();
            SceneController.getInstance().LoadingScene("LevelTwo");
        }
        else if (currentLevel == LevelsEnum.LevelTwo) {
            GameController.getInstance().levelNumber = LevelsEnum.LevelThree;
            GameController.getInstance().SaveGame();
            SceneController.getInstance().LoadingScene("LevelThree");
        }
        else if (currentLevel == LevelsEnum.LevelThree) {
            GameController.getInstance().levelNumber = LevelsEnum.LevelFour;
            GameController.getInstance().SaveGame();
            SceneController.getInstance().LoadingScene("LevelFour");
        }
        else if (currentLevel == LevelsEnum.LevelFour) {
            GameController.getInstance().levelNumber = LevelsEnum.LevelFive;
            GameController.getInstance().SaveGame();
            SceneController.getInstance().LoadingScene("LevelFive");
        }
        else if (currentLevel == LevelsEnum.LevelFive) {
            GameController.getInstance().levelNumber = LevelsEnum.LevelSix;
            GameController.getInstance().SaveGame();
            SceneController.getInstance().LoadingScene("LevelSix");
        }
        
        // Debug.Log("Scene Load: NEXT LEVEL");
    }

    // On click methods --------------------------------------------------------------------------------
    private void OnClick_UpgradeWeapon() 
    {
        // Upgrade weapon depending on the players current weapon
        WeaponsEnum currentWeapon = GameController.getInstance().weaponType;
        if(currentWeapon == WeaponsEnum.Pistol) {
            GameController.getInstance().weaponType = WeaponsEnum.DualPistol;
        }
        else if(currentWeapon == WeaponsEnum.DualPistol) {
            GameController.getInstance().weaponType = WeaponsEnum.Rifle;
        }
        else if(currentWeapon == WeaponsEnum.Rifle) {
            GameController.getInstance().weaponType = WeaponsEnum.Shotgun;
        }
        // Debug.Log("UPGRADE WEAPON");
        // Advance to next level
        advanceToNextLevel();
    }
    private void OnClick_UpgradeSpeed() 
    {
        // Speed upgrade depending on the number of times you take the upgrade
        // f(x) = -0.1x^2 + 1.6x + 5 where x is the amount of times the speed upgrade has been taken
        // Diminishing returns on speed
        GameController.getInstance().numSpeedUpgrades += 1;
        int x = GameController.getInstance().numSpeedUpgrades;
        float xSquared = (float)Math.Pow(x, 2);
        float newSpeed = (-0.1f * xSquared) + (1.6f * x) + 5;
        GameController.getInstance().movementSpeed = newSpeed;
        //Debug.Log(GameController.getInstance().movementSpeed);
        //Debug.Log(GameController.getInstance().numSpeedUpgrades);
        // Debug.Log("UPGRADE SPEED");
        // Advance to next level
        advanceToNextLevel();
    }
    private void OnClick_UpgradeHealth() 
    {
        // Increase max health by 30
        GameController.getInstance().setMaxHealth(GameController.getInstance().maxHealth + 40);
        // Debug.Log("UPGRADE HEALTH");
        // Advance to next level
        advanceToNextLevel();
    }
    private void OnClick_UpgradeShield() 
    {
        // If player has shield already, top up the shield, else give them a shield with full armor
        if(GameController.getInstance().hasShield) {
            GameController.getInstance().setShield(GameController.getInstance().maxShield);
        }
        else {
            GameController.getInstance().hasShield = true;
            GameController.getInstance().setShield(GameController.getInstance().maxShield);
        }
        // Debug.Log("UPGRADE SHIELD");
        // Advance to next level
        advanceToNextLevel();
    }
    private void OnClick_NoUpgrade()
    {
        // Debug.Log("NO UPGRADE");
        // Advance to next level
        advanceToNextLevel();
    }

    private void ResetTime()
    {
        Levels.setTimeScale(1f);
        Levels.isPaused = false;
    }
}
