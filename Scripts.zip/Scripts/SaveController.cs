using System;
using System.IO;
using UnityEngine;

public class SaveController : MonoBehaviour
{
    // saving and loading into/from JSON file
    public static string directory = "/SaveData/";
    public static string fileName = "playerGameData.txt";

    public static void Save() 
    {
        // Save into JSON format in the persistent directory from the GameController Instance
        string dir = Application.persistentDataPath + directory;
        SaveObject toSave = new SaveObject();

        // Data to Save
        toSave._playerName = GameController.getInstance().playerName;
        toSave._score = GameController.getInstance().score;
        toSave._levelNumber = GameController.getInstance().levelNumber;
        toSave._weaponType = GameController.getInstance().weaponType;
        //toSave._health = GameController.getInstance().health;
        toSave._maxHealth = GameController.getInstance().maxHealth;
        toSave._hasShield = GameController.getInstance().hasShield;
        toSave._shield = GameController.getInstance().shield;
        toSave._maxShield = GameController.getInstance().maxShield;
        toSave._movementSpeed = GameController.getInstance().movementSpeed;
        toSave._numSpeedUpgrades = GameController.getInstance().numSpeedUpgrades;

        if (!Directory.Exists(dir))
        {
            Directory.CreateDirectory(dir);
        }

        string json = JsonUtility.ToJson(toSave);
        File.WriteAllText(dir + fileName, json);
    }

    public static bool Load() 
    {
        // load from JSON format in the persistent directory into the GameController Instance
        string fullpath = Application.persistentDataPath + directory + fileName;
        SaveObject loadedIn = new SaveObject();

        if(File.Exists(fullpath))
        {
            string json = File.ReadAllText(fullpath);
            try {
                loadedIn = JsonUtility.FromJson<SaveObject>(json);
                // Data to load
                GameController.getInstance().playerName = loadedIn._playerName;
                GameController.getInstance().setScore(loadedIn._score);
                GameController.getInstance().levelNumber = loadedIn._levelNumber;
                GameController.getInstance().weaponType = loadedIn._weaponType;
                //GameController.getInstance().setHealth(loadedIn._health);
                GameController.getInstance().setMaxHealth(loadedIn._maxHealth);
                GameController.getInstance().hasShield = loadedIn._hasShield;
                GameController.getInstance().setShield(loadedIn._shield);
                GameController.getInstance().setMaxShield(loadedIn._maxShield);
                GameController.getInstance().movementSpeed = loadedIn._movementSpeed;
                GameController.getInstance().numSpeedUpgrades = loadedIn._numSpeedUpgrades;
            }
            catch (Exception exc) {
                // if error in load file, return false and delete that file
                Debug.Log(exc);
                DeleteSaveFile();
                return false;
            }

            return true;
        }
        else
        {
            // Debug.Log("Save file doesnt exist");
            return false;
        }
    }

    public static bool canLoad()
    {
        // checks to see if there is file that be loaded for the game
        string fullpath = Application.persistentDataPath + directory + fileName;
        if(File.Exists(fullpath)){
            // Debug.Log("DATA FOUND");
            return true;
        }
        else {
            // Debug.Log("DATA NOT FOUND");
            return false;
        }
    }

    public static void DeleteSaveFile() 
    {
        // checks to see if file exists first
        string fullpath = Application.persistentDataPath + directory + fileName;
        if(File.Exists(fullpath)){
            // Debug.Log("DELETE FILE");
            File.Delete(fullpath);
        }
    }

    [SerializeField]
    public class SaveObject
    {
        public string _playerName = "Commander";
        public int _score = 0;
        public LevelsEnum _levelNumber = LevelsEnum.LevelOne;
        public WeaponsEnum _weaponType = WeaponsEnum.Pistol;
        //public int _health;
        public int _maxHealth = 100;
        public bool _hasShield = false;
        public int _shield = 0;
        public int _maxShield = 100;
        public float _movementSpeed = 5f;
        public int _numSpeedUpgrades = 0;
    }
}
