using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TSHighScores : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject BackButton;
    private GameObject positionText;
    private GameObject nameText;
    private GameObject scoreText;
    private GameObject HSHolder;
    private GameObject template;
    private GameObject tempPos;
    private GameObject tempName;
    private GameObject tempScore;
    private GameObject tempTrophy;
    private List<HighScore.HighScoreEntry> highScoreList;
    private List<GameObject> highScoreGOList;

    private Color viewBackgroundColor;

    private void Awake()
    {        
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold the input field and button
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (900f, 620f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // High scores heading
        Heading = new GameObject();
        Heading = ComponentMethods.createTextGO(Heading, "HeadingHighScores", Back);
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 0f, 120f, RectTransform.Edge.Left, 0f, 900f);
        Heading = ComponentMethods.setTextProperties(Heading, "HIGH SCORES", 
                                                    AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 100, TextAnchor.MiddleCenter, Color.black);

        // Back to main title screen button
        BackButton = new GameObject();
        BackButton = ComponentMethods.createButtonGO(BackButton, "BackButton", Back);
        BackButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().Back;
        BackButton.GetComponent<Image>().SetNativeSize();
        BackButton.GetComponent<Button>().onClick.AddListener(OnClick_Back);
        BackButton = ComponentMethods.setPositionFromParent(BackButton, RectTransform.Edge.Top, 20f, 68f, RectTransform.Edge.Left, 20f, 98f);

        // Colomn heading texts
        positionText = new GameObject();
        positionText = ComponentMethods.createTextGO(positionText, "Position", Back);
        positionText = ComponentMethods.setPositionFromParent(positionText, RectTransform.Edge.Top, 120f, 60f, RectTransform.Edge.Left, 20f, 160f);
        positionText = ComponentMethods.setTextProperties(positionText, "POS", AssetsHolder.getInstance().shareTechMono, 
                                                         FontStyle.Bold, 50, TextAnchor.MiddleCenter, Color.black);
        nameText = new GameObject();
        nameText = ComponentMethods.createTextGO(nameText, "Name", Back);
        nameText = ComponentMethods.setPositionFromParent(nameText, RectTransform.Edge.Top, 120f, 60f, RectTransform.Edge.Left, 180f, 400f);
        nameText = ComponentMethods.setTextProperties(nameText, "NAME", AssetsHolder.getInstance().shareTechMono, 
                                                         FontStyle.Bold, 50, TextAnchor.MiddleCenter, Color.black);
        scoreText = new GameObject();
        scoreText = ComponentMethods.createTextGO(scoreText, "Score", Back);
        scoreText = ComponentMethods.setPositionFromParent(scoreText, RectTransform.Edge.Top, 120f, 60f, RectTransform.Edge.Left, 580f, 300f);
        scoreText = ComponentMethods.setTextProperties(scoreText, "SCORE", AssetsHolder.getInstance().shareTechMono, 
                                                         FontStyle.Bold, 50, TextAnchor.MiddleCenter, Color.black);

        // Container holding all the entries
        HSHolder = new GameObject();
        HSHolder = ComponentMethods.createEmptyGO(HSHolder, "HSContainer", Back);
        HSHolder = ComponentMethods.setPositionFromParent(HSHolder, RectTransform.Edge.Top, 180f, 400f, RectTransform.Edge.Left, 20f, 860f);
        
        //High score entry template
        template = new GameObject();
        template = ComponentMethods.createEmptyGO(template, "temp", Back);
        template = ComponentMethods.setPositionFromParent(template, RectTransform.Edge.Top, 180f, 40f, RectTransform.Edge.Left, 20f, 860f);

        tempPos = new GameObject();
        tempPos = ComponentMethods.createTextGO(tempPos, "Position", template);
        tempPos = ComponentMethods.setPositionFromParent(tempPos, RectTransform.Edge.Top, 0f, 40f, RectTransform.Edge.Left, 0f, 160f);
        tempPos = ComponentMethods.setTextProperties(tempPos, "#1", AssetsHolder.getInstance().shareTechMono, 
                                                         FontStyle.Bold, 30, TextAnchor.MiddleCenter, Color.black);

        tempTrophy = new GameObject();
        tempTrophy = ComponentMethods.createImageGO(tempTrophy, "Trophy", template);
        tempTrophy.GetComponent<Image>().sprite = AssetsHolder.getInstance().Trophy;
        tempTrophy = ComponentMethods.setPositionFromParent(tempTrophy, RectTransform.Edge.Top, 2.5f, 35f, RectTransform.Edge.Left, 0f, 35f);

        tempName = new GameObject();
        tempName = ComponentMethods.createTextGO(tempName, "Name", template);
        tempName = ComponentMethods.setPositionFromParent(tempName, RectTransform.Edge.Top, 0f, 40f, RectTransform.Edge.Left, 160f, 400f);
        tempName = ComponentMethods.setTextProperties(tempName, "PLAYER123456789", AssetsHolder.getInstance().shareTechMono, 
                                                         FontStyle.Bold, 30, TextAnchor.MiddleCenter, Color.black);
        tempScore = new GameObject();
        tempScore = ComponentMethods.createTextGO(tempScore, "Score", template);
        tempScore = ComponentMethods.setPositionFromParent(tempScore, RectTransform.Edge.Top, 0f, 40f, RectTransform.Edge.Left, 560f, 300f);
        tempScore = ComponentMethods.setTextProperties(tempScore, "0000000", AssetsHolder.getInstance().shareTechMono, 
                                                         FontStyle.Bold, 30, TextAnchor.MiddleCenter, Color.black);

        // Template set to false so is hidden
        template.SetActive(false);
    }

    void Start() 
    {   
        // Load the highscore list from the file and display in the game objects on screen
        highScoreList = GameController.getInstance().getHighScoreList();
        highScoreGOList = new List<GameObject>();
        foreach (HighScore.HighScoreEntry highScoreEntry in highScoreList) {
            createHighScoreEntry(highScoreEntry, HSHolder, highScoreGOList);
        }
    }
    
    // On click methods --------------------------------------------------------------------------------
    private void OnClick_Back() 
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSMain);
        // Debug.Log("BACK TO MAIN");
    }

    private void createHighScoreEntry(HighScore.HighScoreEntry entry, GameObject parentGO, List<GameObject> entryList) 
    {
        // Create a high score entry and add it to the list of game objects
        float tempHeight = 40f;
        GameObject tempGO = Instantiate(template, new Vector3(0f, 0f, 0f), Quaternion.identity, parentGO.transform);
        tempGO = ComponentMethods.setPositionFromParent(tempGO, RectTransform.Edge.Top, entryList.Count * tempHeight, tempHeight, RectTransform.Edge.Left, 0f, 860f);
        tempGO.SetActive(true);
        // set the text of each entry in the gameobject
        tempGO.transform.Find("Position").GetComponent<Text>().text = "#" + (entryList.Count+1);
        tempGO.transform.Find("Name").GetComponent<Text>().text = entry.name;
        tempGO.transform.Find("Score").GetComponent<Text>().text = entry.score.ToString();
        // if in position 1, 2 or 3 make the text yellow
        if ((entryList.Count+1) < 4) {
            tempGO.transform.Find("Position").GetComponent<Text>().color = Color.yellow;
            tempGO.transform.Find("Name").GetComponent<Text>().color = Color.yellow;
            tempGO.transform.Find("Score").GetComponent<Text>().color = Color.yellow;
        }
        // if in position 1,2 or 3 set the trophy to active and the colour
        switch((entryList.Count+1)) {
            default: 
                tempGO.transform.Find("Trophy").gameObject.SetActive(false);
            break;
            case 1:
                tempGO.transform.Find("Trophy").GetComponent<Image>().color = new Color(255f/255f, 210f/255f, 0f);
            break;
            case 2:
                tempGO.transform.Find("Trophy").GetComponent<Image>().color = new Color(198f/255f, 198f/255f, 198f/255f);
            break;
            case 3:
                tempGO.transform.Find("Trophy").GetComponent<Image>().color = new Color(183f/255f, 111f/255f, 86f/255f);
            break;
        }

        entryList.Add(tempGO);
    }
}
