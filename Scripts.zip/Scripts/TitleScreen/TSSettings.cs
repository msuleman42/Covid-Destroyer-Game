using UnityEngine;
using UnityEngine.UI;

public class TSSettings : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject BackButton;
    private GameObject backgroundMusicText;
    private GameObject backgroundMusicSlider;
    private GameObject backgrounfMusicSliderValueText;
    private GameObject soundEffectsVolumeText;
    private GameObject soundEffectsVolumeSlider;
    private GameObject soundEffectsSliderValueText;
    private GameObject resolutionText;
    private GameObject toggleGroupRes;
    private GameObject toggleFullScreen;
    private GameObject toggle1080p;
    private GameObject toggle720p;
    private GameObject toggle540p;
    private GameObject toggle480p;

    private Color viewBackgroundColor;

    private void Awake()
    {
        // Debug.Log("Is fullscreen: " + Screen.fullScreen);
        // Debug.Log("Current Resolution: " + Screen.width + " x " + Screen.height);
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold the input field and button
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (600f, 530f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Settings heading
        Heading = new GameObject();
        Heading = ComponentMethods.createTextGO(Heading, "Settings", Back);
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 0f, 100f, RectTransform.Edge.Left, 0f, 600f);
        Heading = ComponentMethods.setTextProperties(Heading, "SETTINGS",
                                                     AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 80, TextAnchor.MiddleCenter, Color.black);

        // Back to main title screen button
        BackButton = new GameObject();
        BackButton = ComponentMethods.createButtonGO(BackButton, "BackButton", Back);
        BackButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().Back;
        BackButton.GetComponent<Image>().SetNativeSize();
        BackButton.GetComponent<Button>().onClick.AddListener(OnClick_Back);
        BackButton = ComponentMethods.setPositionFromParent(BackButton, RectTransform.Edge.Top, 10f, 68f, RectTransform.Edge.Left, 10f, 98f);

        // Background Music Text for slider
        backgroundMusicText = new GameObject();
        backgroundMusicText = ComponentMethods.createTextGO(backgroundMusicText, "BackgrounMusicText", Back);
        backgroundMusicText = ComponentMethods.setPositionFromParent(backgroundMusicText, RectTransform.Edge.Top, 100f, 50f, RectTransform.Edge.Left, 20f, 560f);
        backgroundMusicText = ComponentMethods.setTextProperties(backgroundMusicText, "Background Music Volume:",
                                                     AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 30, TextAnchor.MiddleLeft, Color.black);

        backgroundMusicSlider = new GameObject();
        backgroundMusicSlider = ComponentMethods.createEmptyGO(backgroundMusicSlider, "bgMusicSlider", Back);
        backgroundMusicSlider = createSliderGO(backgroundMusicSlider);
        backgroundMusicSlider = ComponentMethods.setPositionFromParent(backgroundMusicSlider, RectTransform.Edge.Top, 170f, 30f, RectTransform.Edge.Left, 100f, 300f);
        backgroundMusicSlider.GetComponent<Slider>().onValueChanged.AddListener(value => setBackgroundMusicLevel(backgroundMusicSlider.GetComponent<Slider>().value));

        backgrounfMusicSliderValueText = new GameObject();
        backgrounfMusicSliderValueText = ComponentMethods.createTextGO(backgrounfMusicSliderValueText, "BMSliderValue", Back);
        backgrounfMusicSliderValueText = ComponentMethods.setPositionFromParent(backgrounfMusicSliderValueText, RectTransform.Edge.Top, 160f, 50f,
                                                                                 RectTransform.Edge.Left, 420f, 100f);
        backgrounfMusicSliderValueText = ComponentMethods.setTextProperties(backgrounfMusicSliderValueText, "50", 
                                                                            AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 30, TextAnchor.MiddleCenter, Color.white);

        // Sound Effects Text for slider
        soundEffectsVolumeText = new GameObject();
        soundEffectsVolumeText = ComponentMethods.createTextGO(soundEffectsVolumeText, "SoundEffectsText", Back);
        soundEffectsVolumeText = ComponentMethods.setPositionFromParent(soundEffectsVolumeText, RectTransform.Edge.Top, 220f, 50f, RectTransform.Edge.Left, 20f, 560f);
        soundEffectsVolumeText = ComponentMethods.setTextProperties(soundEffectsVolumeText, "Sound Effects Volume:",
                                                     AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 30, TextAnchor.MiddleLeft, Color.black);
        
        soundEffectsVolumeSlider = new GameObject();
        soundEffectsVolumeSlider = ComponentMethods.createEmptyGO(soundEffectsVolumeSlider, "sfxSlider", Back);
        soundEffectsVolumeSlider = createSliderGO(soundEffectsVolumeSlider);
        soundEffectsVolumeSlider = ComponentMethods.setPositionFromParent(soundEffectsVolumeSlider, RectTransform.Edge.Top, 290f, 30f, RectTransform.Edge.Left, 100f, 300f);
        soundEffectsVolumeSlider.GetComponent<Slider>().onValueChanged.AddListener(value => setSoundEffectsLevel(soundEffectsVolumeSlider.GetComponent<Slider>().value));

        soundEffectsSliderValueText = new GameObject();
        soundEffectsSliderValueText = ComponentMethods.createTextGO(soundEffectsSliderValueText, "SFXSliderValue", Back);
        soundEffectsSliderValueText = ComponentMethods.setPositionFromParent(soundEffectsSliderValueText, RectTransform.Edge.Top, 280f, 50f,
                                                                                 RectTransform.Edge.Left, 420f, 100f);
        soundEffectsSliderValueText = ComponentMethods.setTextProperties(soundEffectsSliderValueText, "50", 
                                                                            AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 30, TextAnchor.MiddleCenter, Color.white);
        
        backgroundMusicSlider.GetComponent<Slider>().value = AudioController.getInstance().backgroundMusicVolume;
        soundEffectsVolumeSlider.GetComponent<Slider>().value = AudioController.getInstance().soundEffectsVolume;

        // Resolution Text
        resolutionText = new GameObject();
        resolutionText = ComponentMethods.createTextGO(resolutionText, "ResolutionText", Back);
        resolutionText = ComponentMethods.setPositionFromParent(resolutionText, RectTransform.Edge.Top, 340f, 50f, RectTransform.Edge.Left, 20f, 250f);
        resolutionText = ComponentMethods.setTextProperties(resolutionText, "Resolution:",
                                                     AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 30, TextAnchor.MiddleLeft, Color.black);
        
        toggleGroupRes = new GameObject();
        toggleGroupRes = ComponentMethods.createEmptyGO(toggleGroupRes, "ToggleGroupResolution", Back);
        toggleGroupRes.AddComponent<ToggleGroup>();

        toggleFullScreen = new GameObject();
        toggleFullScreen = ComponentMethods.createEmptyGO(toggleFullScreen, "FullScreenToggle", Back);
        toggleFullScreen = createToggleGO(toggleFullScreen, "FULLSCREEN");
        if (Screen.fullScreen) {
            toggleFullScreen.GetComponent<Toggle>().isOn = true;
        }
        toggleFullScreen.GetComponent<Toggle>().onValueChanged.AddListener(setFullscreenRes);
        toggleFullScreen = ComponentMethods.setPositionFromParent(toggleFullScreen, RectTransform.Edge.Top, 480f, 30f, RectTransform.Edge.Left, 175f, 250f);

        toggle1080p = new GameObject();
        toggle1080p = ComponentMethods.createEmptyGO(toggle1080p, "1080Toggle", Back);
        toggle1080p = createToggleGO(toggle1080p, "1920 x 1080");
        toggle1080p.GetComponent<Toggle>().group = toggleGroupRes.GetComponent<ToggleGroup>();
        if (Screen.height == 1080) {
            toggle1080p.GetComponent<Toggle>().isOn = true;
        }
        toggle1080p.GetComponent<Toggle>().onValueChanged.AddListener(set1080pRes);
        toggle1080p = ComponentMethods.setPositionFromParent(toggle1080p, RectTransform.Edge.Top, 400f, 30f, RectTransform.Edge.Left, 20f, 250f);

        toggle720p = new GameObject();
        toggle720p = ComponentMethods.createEmptyGO(toggle720p, "720Toggle", Back);
        toggle720p = createToggleGO(toggle720p, "1280 x 720");
        toggle720p.GetComponent<Toggle>().group = toggleGroupRes.GetComponent<ToggleGroup>();
        if (Screen.height == 720) {
            toggle720p.GetComponent<Toggle>().isOn = true;
        }
        toggle720p.GetComponent<Toggle>().onValueChanged.AddListener(set720pRes);
        toggle720p = ComponentMethods.setPositionFromParent(toggle720p, RectTransform.Edge.Top, 440f, 30f, RectTransform.Edge.Left, 20f, 250f);

        toggle540p = new GameObject();
        toggle540p = ComponentMethods.createEmptyGO(toggle540p, "540Toggle", Back);
        toggle540p = createToggleGO(toggle540p, "960 x 540");
        toggle540p.GetComponent<Toggle>().group = toggleGroupRes.GetComponent<ToggleGroup>();
        if (Screen.height == 540) {
            toggle540p.GetComponent<Toggle>().isOn = true;
        }
        toggle540p.GetComponent<Toggle>().onValueChanged.AddListener(set540pRes);
        toggle540p = ComponentMethods.setPositionFromParent(toggle540p, RectTransform.Edge.Top, 400f, 30f, RectTransform.Edge.Left, 330f, 250f);

        toggle480p = new GameObject();
        toggle480p = ComponentMethods.createEmptyGO(toggle480p, "480Toggle", Back);
        toggle480p = createToggleGO(toggle480p, "852 x 480");
        toggle480p.GetComponent<Toggle>().group = toggleGroupRes.GetComponent<ToggleGroup>();
        if (Screen.height == 480) {
            toggle480p.GetComponent<Toggle>().isOn = true;
        }
        toggle480p.GetComponent<Toggle>().onValueChanged.AddListener(set480pRes);
        toggle480p = ComponentMethods.setPositionFromParent(toggle480p, RectTransform.Edge.Top, 440f, 30f, RectTransform.Edge.Left, 330f, 250f);

    }

    void Start() 
    {
        backgrounfMusicSliderValueText.GetComponent<Text>().text = ((int)Mathf.Round((backgroundMusicSlider.GetComponent<Slider>().value * 100))).ToString();
        soundEffectsSliderValueText.GetComponent<Text>().text = ((int)Mathf.Round((soundEffectsVolumeSlider.GetComponent<Slider>().value * 100))).ToString();
    }


    // Make a slider function
    private GameObject createSliderGO(GameObject go)
    {
        go.GetComponent<RectTransform>().sizeDelta = new Vector2(300f, 30f);
        go.AddComponent<Slider>();
        go.GetComponent<Slider>().transition = Selectable.Transition.None;
        go.GetComponent<Slider>().navigation = Navigation.defaultNavigation;
        go.GetComponent<Slider>().direction = Slider.Direction.LeftToRight;
        go.GetComponent<Slider>().minValue = 0.0001f;
        go.GetComponent<Slider>().maxValue = 1f;
        
        GameObject sliderBackground = new GameObject();
        sliderBackground = ComponentMethods.createImageGO(sliderBackground, "SliderBackground", go);
        sliderBackground.GetComponent<Image>().color = Color.grey;
        sliderBackground = ComponentMethods.setPositionFromParent(sliderBackground, RectTransform.Edge.Left, 0f, 300f, RectTransform.Edge.Top, 7.5f, 15f);

        GameObject fillArea = new GameObject();
        fillArea = ComponentMethods.createEmptyGO(fillArea, "FillArea", go);
        fillArea = ComponentMethods.setPositionFromParent(fillArea, RectTransform.Edge.Left, 5f, 290f, RectTransform.Edge.Top, 7.5f, 15f);

        GameObject fill = new GameObject();
        fill = ComponentMethods.createImageGO(fill, "Fill", fillArea);
        fill.GetComponent<Image>().color = Color.white;
        fill = ComponentMethods.setPositionFromParent(fill, RectTransform.Edge.Left, 0f, 0f, RectTransform.Edge.Top, 0f, 0f);
        
        GameObject handleSlideArea = new GameObject();
        handleSlideArea = ComponentMethods.createEmptyGO(handleSlideArea, "HandleSlideArea", go);
        handleSlideArea = ComponentMethods.setPositionFromParent(handleSlideArea, RectTransform.Edge.Left, 5f, 290f, RectTransform.Edge.Top, 0f, 30f);

        GameObject handle = new GameObject();
        handle = ComponentMethods.createImageGO(handle, "Handle", handleSlideArea);
        handle.GetComponent<Image>().sprite = AssetsHolder.getInstance().Handle;
        handle = ComponentMethods.setPositionFromParent(handle, RectTransform.Edge.Left, -5f, 20f, RectTransform.Edge.Top, 0f, 0f);

        go.GetComponent<Slider>().fillRect = fill.GetComponent<RectTransform>();
        go.GetComponent<Slider>().handleRect = handle.GetComponent<RectTransform>();

        return go;
    }

    // Make a toggle function
    private GameObject createToggleGO(GameObject go, string name)
    {
        // main 250 by 30, box 30by30, text rest
        go.GetComponent<RectTransform>().sizeDelta = new Vector2(250f, 30f);
        go.AddComponent<Toggle>();
        go.GetComponent<Toggle>().transition = Selectable.Transition.None;
        go.GetComponent<Toggle>().isOn = false;

        GameObject toggleBackground = new GameObject();
        toggleBackground = ComponentMethods.createImageGO(toggleBackground, "ToggleBackground", go);
        toggleBackground.GetComponent<Image>().sprite = AssetsHolder.getInstance().ToggleBoxEmpty;
        toggleBackground.GetComponent<Image>().SetNativeSize();
        toggleBackground = ComponentMethods.setPositionFromParent(toggleBackground, RectTransform.Edge.Left, 0f, 30f, RectTransform.Edge.Top, 0f, 30f);

        GameObject checkMark = new GameObject();
        checkMark = ComponentMethods.createImageGO(checkMark, "CheckMark", toggleBackground);
        checkMark.GetComponent<Image>().sprite = AssetsHolder.getInstance().CheckMark;
        checkMark.GetComponent<Image>().SetNativeSize();
        checkMark = ComponentMethods.setPositionFromParent(checkMark, RectTransform.Edge.Left, 2.5f, 25f, RectTransform.Edge.Top, 2.5f, 25f);

        GameObject label = new GameObject();
        label = ComponentMethods.createTextGO(label, "Label", go);
        label = ComponentMethods.setPositionFromParent(label, RectTransform.Edge.Left, 40f, 210f, RectTransform.Edge.Top, 0f, 30f);
        label = ComponentMethods.setTextProperties(label, name, AssetsHolder.getInstance().shareTechMono, FontStyle.Normal, 25, TextAnchor.MiddleLeft, Color.white);

        go.GetComponent<Toggle>().graphic = checkMark.GetComponent<Image>();

        return go;
    }
    
    // On click methods, slider methods and toggle methods ----------------------------------------------------------------------------
    private void OnClick_Back() 
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSMain);
        // Debug.Log("BACK TO MAIN");
    }

    private void setBackgroundMusicLevel(float volume) 
    {
        AudioController.getInstance().setBackgroundMusicVolume(volume);
        int volumeRounded = (int)Mathf.Round(volume * 100);
        backgrounfMusicSliderValueText.GetComponent<Text>().text = volumeRounded.ToString();
    }

    private void setSoundEffectsLevel(float volume)
    {
        AudioController.getInstance().setSoundEffectsVolume(volume);
        int volumeRounded = (int)Mathf.Round(volume * 100);
        soundEffectsSliderValueText.GetComponent<Text>().text = volumeRounded.ToString();
    }

    private void setFullscreenRes(bool enableToggle) 
    {
        if(enableToggle) {
            // Debug.Log("RES CHANGED: FULLSCREEN");
            Screen.fullScreen = true;
        }
        else {
            // Debug.Log("RES NOT FULLSCREEN");
            Screen.fullScreen = false;
        }
    }

    private void set1080pRes(bool enableToggle)
    {
        if(enableToggle) {
            // Debug.Log("RES CHANGED: 1080p");
            Screen.SetResolution(1920, 1080, Screen.fullScreen);
        }
    }

    private void set720pRes(bool enableToggle)
    {
        if(enableToggle) {
            // Debug.Log("RES CHANGED: 720p");
            Screen.SetResolution(1280, 720, Screen.fullScreen);
        }
    }

    private void set540pRes(bool enableToggle)
    {
        if(enableToggle) {
            // Debug.Log("RES CHANGED: 540p");
            Screen.SetResolution(960, 540, Screen.fullScreen);
        }
    }

    private void set480pRes(bool enableToggle)
    {
        if(enableToggle) {
            // Debug.Log("RES CHANGED: 480p");
            Screen.SetResolution(852, 480, Screen.fullScreen);
        }   
    }
}
