using UnityEngine;
using UnityEngine.UI;

public class TSEnterName : MonoBehaviour
{
    private GameObject Back;
    private GameObject guideText;
    private GameObject inputField;
    private GameObject placeHolder;
    private GameObject inputText;
    private GameObject enterButton;
    private GameObject enterButtonText;

    private Color viewBackgroundColor;

    private void Awake()
    {
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold the input field and button
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (450f, 215f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Text telling user what to input
        guideText = new GameObject();
        guideText = ComponentMethods.createTextGO(guideText, "GuideText", Back);
        guideText = ComponentMethods.setPositionFromParent(guideText, RectTransform.Edge.Left, 25f, 400f, RectTransform.Edge.Top, 10f, 50f);
        guideText = ComponentMethods.setTextProperties(guideText, "Enter Name Below:", 
                                                        AssetsHolder.getInstance().chakraPetch, FontStyle.Bold, 30, TextAnchor.MiddleLeft, Color.black);

        // Input filed for user to put in name
        inputField = new GameObject();
        inputField = ComponentMethods.createInputFieldGO(inputField, "InputField", Back);
        inputField = ComponentMethods.setPositionFromParent(inputField, RectTransform.Edge.Left, 25f, 400f, RectTransform.Edge.Top, 65f, 50f);

        // Place holder text in input field
        placeHolder = new GameObject();
        placeHolder = ComponentMethods.createTextGO(placeHolder, "PlaceHolder", inputField);
        placeHolder = ComponentMethods.setPositionFromParent(placeHolder, RectTransform.Edge.Left, 10f, 380f, RectTransform.Edge.Top, 0f, 50f);
        placeHolder = ComponentMethods.setTextProperties(placeHolder, "Enter text...",
                                                           AssetsHolder.getInstance().chakraPetch, FontStyle.Italic, 30, TextAnchor.MiddleLeft, Color.grey);

        // Input text of user
        inputText = new GameObject();
        inputText = ComponentMethods.createTextGO(inputText, "InputText", inputField);
        inputText = ComponentMethods.setPositionFromParent(inputText, RectTransform.Edge.Left, 10f, 380f, RectTransform.Edge.Top, 0f, 50f);
        inputText = ComponentMethods.setTextProperties(inputText, "", AssetsHolder.getInstance().chakraPetch, FontStyle.Italic, 30, TextAnchor.MiddleLeft, Color.black);

        // Assign text and placeholder to inputfield component
        inputField.GetComponent<InputField>().placeholder = placeHolder.GetComponent<Text>();
        inputField.GetComponent<InputField>().textComponent = inputText.GetComponent<Text>();
        inputField.GetComponent<InputField>().characterLimit = 15;

        // Button to enter name
        enterButton = new GameObject();
        enterButton = ComponentMethods.createButtonGO(enterButton, "EnterButton", Back);
        enterButton = ComponentMethods.setPositionFromParent(enterButton, RectTransform.Edge.Left, 25f, 400f, RectTransform.Edge.Top, 140f, 50f);
        enterButton.GetComponent<Button>().onClick.AddListener(OnClick_Enter);

        // Text on Button
        enterButtonText = new GameObject();
        enterButtonText = ComponentMethods.createTextGO(enterButtonText, "EnterButtonText", enterButton);
        enterButtonText = ComponentMethods.setPositionFromParent(enterButtonText, RectTransform.Edge.Left, 0f, 400f, RectTransform.Edge.Top, 0f, 50f);
        enterButtonText = ComponentMethods.setTextProperties(enterButtonText, "ENTER", 
                                                             AssetsHolder.getInstance().chakraPetch, FontStyle.Normal, 30, TextAnchor.MiddleCenter, Color.black);


    }

    void Start() {
        // auto go on the input field instead of the user having to click there
        inputField.GetComponent<InputField>().Select();
    }

    void Update()
    {
        // User presses enter to move to next view or presses the button
        if (Input.GetKeyUp(KeyCode.Return)) {
            nameEntered();
            // Debug.Log("Enter Key Pressed");
        }
    }

    private void nameEntered() 
    {
        // Saves name to game controller and displays the next scene
        string userInput = inputText.GetComponent<Text>().text;
        // if input field is empty, ake the username Commander
        if (string.IsNullOrEmpty(userInput)) {
            userInput = "Commander";
        }
        GameController.getInstance().playerName = userInput;
        //Transition to next scene
        SceneController.getInstance().LoadingScene("LevelOne");
        // Debug.Log("Scene Load: LEVEL ONE");
    }

    // Button on click methods ---------------------------------------------------------------------------------------
    public void OnClick_Enter()
    {
        nameEntered();
    }
}
