using UnityEngine;
using UnityEngine.UI;

public class TSMain : MonoBehaviour
{
    private GameObject GameTitle;
    private GameObject SettingsButton;
    private GameObject QuitButton;
    private GameObject ButtonsHolder;
    private GameObject NewGameButton;
    private GameObject LoadGameButton;
    private GameObject HowToPlayButton;
    private GameObject HighScoresButton;

    private void Awake()
    {
        // set and position the title
        GameTitle = new GameObject();
        GameTitle = ComponentMethods.createImageGO(GameTitle, "GameTitle", this.gameObject, new Vector3(1f, 1f, 1f), new Vector3(0f, 230f, 0f));
        GameTitle.GetComponent<Image>().sprite = AssetsHolder.getInstance().GameTitle;
        GameTitle.GetComponent<Image>().SetNativeSize();

        // Game object to hold the 4 main buttons
        ButtonsHolder = new GameObject();
        ButtonsHolder = ComponentMethods.createEmptyGO(ButtonsHolder, "ButtonsHolder", this.gameObject, new Vector3(1f, 1f, 1f), new Vector3(0f, -100f, 0f));
        ButtonsHolder.GetComponent<RectTransform>().sizeDelta = new Vector2(400f, 430f);
        
        // NewGame button creation and position
        NewGameButton = new GameObject();
        NewGameButton = ComponentMethods.createButtonGO(NewGameButton, "NewGameButton", ButtonsHolder);
        NewGameButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().NewGame;
        NewGameButton.GetComponent<Image>().SetNativeSize();
        NewGameButton.GetComponent<Button>().onClick.AddListener(OnClick_NewGame);
        NewGameButton = ComponentMethods.setPositionFromParent(NewGameButton, RectTransform.Edge.Top, 0f, 100f, RectTransform.Edge.Left, 0f, 400f);
        
        // LoadGame button creation and position
        LoadGameButton = new GameObject();
        LoadGameButton = ComponentMethods.createButtonGO(LoadGameButton, "LoadGameButton", ButtonsHolder);
        LoadGameButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().LoadGame;
        LoadGameButton.GetComponent<Image>().SetNativeSize();
        LoadGameButton.GetComponent<Button>().onClick.AddListener(OnClick_LoadGame);
        LoadGameButton = ComponentMethods.setPositionFromParent(LoadGameButton, RectTransform.Edge.Top, 110f, 100f, RectTransform.Edge.Left, 0f, 400f);

        // HowToPlay button creation and position
        HowToPlayButton = new GameObject();
        HowToPlayButton = ComponentMethods.createButtonGO(HowToPlayButton, "HowToPlayButton", ButtonsHolder);
        HowToPlayButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().HowToPlay;
        HowToPlayButton.GetComponent<Image>().SetNativeSize();
        HowToPlayButton.GetComponent<Button>().onClick.AddListener(OnClick_HowToPlay);
        HowToPlayButton = ComponentMethods.setPositionFromParent(HowToPlayButton, RectTransform.Edge.Top, 220f, 100f, RectTransform.Edge.Left, 0f, 400f);

        // HighScores button creation and position
        HighScoresButton = new GameObject();
        HighScoresButton = ComponentMethods.createButtonGO(HighScoresButton, "HighScoresButton", ButtonsHolder);
        HighScoresButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().HighScores;
        HighScoresButton.GetComponent<Image>().SetNativeSize();
        HighScoresButton.GetComponent<Button>().onClick.AddListener(OnClick_HighScores);
        HighScoresButton = ComponentMethods.setPositionFromParent(HighScoresButton, RectTransform.Edge.Top, 330f, 100f, RectTransform.Edge.Left, 0f, 400f);

        // Quit button creation and position
        QuitButton = new GameObject();
        QuitButton = ComponentMethods.createButtonGO(QuitButton, "QuitButton", this.gameObject);
        QuitButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().Quit;
        QuitButton.GetComponent<Image>().SetNativeSize();
        QuitButton.GetComponent<Button>().onClick.AddListener(OnClick_Quit);
        QuitButton = ComponentMethods.setPositionFromParent(QuitButton, RectTransform.Edge.Top, 10f, 50f, RectTransform.Edge.Right, 10f, 50f);

        // Settings button creation and position
        SettingsButton = new GameObject();
        SettingsButton = ComponentMethods.createButtonGO(SettingsButton, "SettingsButton", this.gameObject);
        SettingsButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().Settings;
        SettingsButton.GetComponent<Image>().SetNativeSize();
        SettingsButton.GetComponent<Button>().onClick.AddListener(OnClick_Settings);
        SettingsButton = ComponentMethods.setPositionFromParent(SettingsButton, RectTransform.Edge.Top, 10f, 50f, RectTransform.Edge.Left, 10f, 50f);

    }

    private string getLevelToLoad(LevelsEnum levelName) 
    {
        // return a string of the level name 
        if (levelName == LevelsEnum.LevelTwo) {
            return "LevelTwo";
        }
        else if (levelName == LevelsEnum.LevelThree) {
            return "LevelThree";
        }
        else if (levelName == LevelsEnum.LevelFour) {
            return "LevelFour";
        }
        else if (levelName == LevelsEnum.LevelFive) {
            return "LevelFive";
        }
        else if (levelName == LevelsEnum.LevelSix) {
            return "LevelSix";
        }
        else {
            return "LevelOne";
        }
    }

    // Button on click methods ------------------------------------------------------------------------------------
    private void OnClick_NewGame() 
    {
        // Checks to see if there is a load game that is about to be overwritten
        if (GameController.getInstance().canLoadGame()) {
            TitleScreen.SwitchView(ViewsTitleScreen.TSNewGameConfirm);
            // Debug.Log("NEW GAME");
        }
        else {
            // Switch to enter name view
            TitleScreen.SwitchView(ViewsTitleScreen.TSEnterName);
            // Debug.Log("NEW GAME");
        }
    }

    private void OnClick_LoadGame()
    {
        // Checks to see if there is a load game to load up
        if (GameController.getInstance().canLoadGame()) {
            bool hasloaded = GameController.getInstance().LoadGame();
            if(hasloaded) {
                string levelToLoad = getLevelToLoad(GameController.getInstance().levelNumber);
                SceneController.getInstance().LoadingScene(levelToLoad);
                // Debug.Log("LOAD GAME");
                // Debug.Log("Scene Load: LEVEL ???");
            }
            else {
                TitleScreen.SwitchView(ViewsTitleScreen.TSLoadGameNotFound);
                // Debug.Log("LOAD GAME");
            }
        }
        else {
            // No load game found. Show error view
            TitleScreen.SwitchView(ViewsTitleScreen.TSLoadGameNotFound);
            // Debug.Log("LOAD GAME");
        }
    }

    private void OnClick_HowToPlay()
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSHowToPlay);
        // Debug.Log("HOW TO PLAY");
    }

    private void OnClick_HighScores()
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSHighScores);
        // Debug.Log("HIGH SCORES");
    }

    private void OnClick_Quit() 
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSQuit);
        // Debug.Log("QUIT");
    }

    private void OnClick_Settings()
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSSettings);
        // Debug.Log("SETTINGS");
    }


}
