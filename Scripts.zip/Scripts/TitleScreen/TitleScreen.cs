using UnityEngine;

public class TitleScreen : MonoBehaviour
{
    private static GameObject TSBackground;
    private static GameObject TSMain;
    private static GameObject TSSettings;
    private static GameObject TSQuit;
    private static GameObject TSHowToPlay;
    private static GameObject TSHighScores;
    private static GameObject TSNewGameConfirm;
    private static GameObject TSLoadGameNotFound;
    private static GameObject TSEnterName;

    private static GameObject currentView;
    private static GameObject previousView;

    // private void Awake()
    // {
    //     float screenHeight = Camera.main.orthographicSize*2;
    //     float screenWidth = (screenHeight / Screen.height) * Screen.width;

    //     Debug.Log("Height: " + screenHeight + "... Width: " + screenWidth);
    //     Debug.Log("Height: " + Screen.height + "... Width: " + Screen.width);
    // }

    private static void Init() 
    {
        
        float screenWidth = AssetsHolder.getInstance().refSW;
        float screenHeight = AssetsHolder.getInstance().refSH;
        
        // set up the views
        GameObject canvas = GameObject.Find("Canvas");

        TSMain = new GameObject();
        TSMain = ComponentMethods.createEmptyGO(TSMain, "Main", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                new Vector2(screenWidth, screenHeight));
        TSMain.AddComponent<TSMain>();
        
        TSSettings = new GameObject();
        TSSettings = ComponentMethods.createEmptyGO(TSSettings, "Settings", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                    new Vector2(screenWidth, screenHeight));
        TSSettings.AddComponent<TSSettings>();

        TSQuit = new GameObject();
        TSQuit = ComponentMethods.createEmptyGO(TSQuit, "Quit", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                new Vector2(screenWidth, screenHeight));
        TSQuit.AddComponent<TSQuit>();

        TSHowToPlay = new GameObject();
        TSHowToPlay = ComponentMethods.createEmptyGO(TSHowToPlay, "HowToPlay", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                     new Vector2(screenWidth, screenHeight));
        TSHowToPlay.AddComponent<TSHowToPlay>();

        TSHighScores = new GameObject();
        TSHighScores = ComponentMethods.createEmptyGO(TSHighScores, "HighScores", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                         new Vector2(screenWidth, screenHeight));
        TSHighScores.AddComponent<TSHighScores>();

        TSNewGameConfirm = new GameObject();
        TSNewGameConfirm = ComponentMethods.createEmptyGO(TSNewGameConfirm, "NewGameConfirm", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                             new Vector2(screenWidth, screenHeight));
        TSNewGameConfirm.AddComponent<TSNewGameConfirm>();

        TSLoadGameNotFound = new GameObject();
        TSLoadGameNotFound = ComponentMethods.createEmptyGO(TSLoadGameNotFound, "LoadGameNotFound", canvas, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f), 
                                                             new Vector2(screenWidth, screenHeight));
        TSLoadGameNotFound.AddComponent<TSLoadGameNotFound>();

        TSEnterName = new GameObject();
        TSEnterName = ComponentMethods.createEmptyGO(TSEnterName, "Username", canvas, new Vector3 (1f, 1f, 1f), 
                                                     new Vector3(0f, 0f, 0f), new Vector2(screenWidth, screenHeight));
        TSEnterName.AddComponent<TSEnterName>();

    }

    private void Start()
    {
        // set up background and views
        TSBackground = new GameObject();
        TSBackground = ComponentMethods.createSpriteGO(TSBackground, "Background", this.gameObject, "Background", new Vector3(100f, 100f, 1f), 
                                                        new Vector3(0f, 0f, 0f), new Vector2(AssetsHolder.getInstance().refSW, AssetsHolder.getInstance().refSH));
        TSBackground.GetComponent<SpriteRenderer>().sprite = AssetsHolder.getInstance().TitleScreenBackground;

        Init();
        
        HideAllViews();
        InitialView(TSMain);
        AudioController.getInstance().changeBackgroundMusic(false);
    }

    // Hide all views in scene
    private void HideAllViews()
    {
        TSMain.SetActive(false);
        TSSettings.SetActive(false);
        TSQuit.SetActive(false);
        TSHowToPlay.SetActive(false);
        TSHighScores.SetActive(false);
        TSNewGameConfirm.SetActive(false);
        TSLoadGameNotFound.SetActive(false);
        TSEnterName.SetActive(false);
        currentView = null;
        previousView = null;
    }

    private void InitialView(GameObject view)
    {
        // set initial view
        view.SetActive(true);
        currentView = view;
    }

    public static void SwitchView(ViewsTitleScreen view)
    {
        // Gets called when views are switched
        previousView = currentView;
        currentView.SetActive(false);
        switch (view)
        {
            case ViewsTitleScreen.TSMain:
                TSMain.SetActive(true);
                currentView = TSMain;
            break;
            case ViewsTitleScreen.TSSettings:
                TSSettings.SetActive(true);
                currentView = TSSettings;
            break;
            case ViewsTitleScreen.TSQuit:
                TSQuit.SetActive(true);
                currentView = TSQuit;
            break;
            case ViewsTitleScreen.TSHowToPlay:
                TSHowToPlay.SetActive(true);
                currentView = TSHowToPlay;
            break;
            case ViewsTitleScreen.TSHighScores:
                TSHighScores.SetActive(true);
                currentView = TSHighScores;
            break;
            case ViewsTitleScreen.TSNewGameConfirm:
                TSNewGameConfirm.SetActive(true);
                currentView = TSNewGameConfirm;
            break;
            case ViewsTitleScreen.TSLoadGameNotFound:
                TSLoadGameNotFound.SetActive(true);
                currentView = TSLoadGameNotFound;
            break;
            case ViewsTitleScreen.TSEnterName:
                TSEnterName.SetActive(true);
                currentView = TSEnterName;
            break;
        }
    }
    
}
