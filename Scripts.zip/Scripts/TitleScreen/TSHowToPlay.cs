using UnityEngine;
using UnityEngine.UI;

public class TSHowToPlay : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject BackButton;
    private GameObject HowToPlayImage;

    private Color viewBackgroundColor;

    private void Awake()
    {        
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold the input field and button
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3 (1f, 1f, 1f), new Vector3 (0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (AssetsHolder.getInstance().refSW - 20f, AssetsHolder.getInstance().refSH - 20f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // How to play heading
        Heading = new GameObject();
        Heading = ComponentMethods.createTextGO(Heading, "HeadingHowToPlay", Back);
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 0f, 120f, RectTransform.Edge.Left, 280f, 700f);
        Heading = ComponentMethods.setTextProperties(Heading, "HOW TO PLAY", 
                                                    AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 100, TextAnchor.MiddleCenter, Color.black);

        // Back to main title screen button
        BackButton = new GameObject();
        BackButton = ComponentMethods.createButtonGO(BackButton, "BackButton", Back);
        BackButton.GetComponent<Image>().sprite = AssetsHolder.getInstance().Back;
        BackButton.GetComponent<Image>().SetNativeSize();
        BackButton.GetComponent<Button>().onClick.AddListener(OnClick_Back);
        BackButton = ComponentMethods.setPositionFromParent(BackButton, RectTransform.Edge.Top, 20f, 68f, RectTransform.Edge.Left, 20f, 98f);

        // How to play image showing controls
        HowToPlayImage = new GameObject();
        HowToPlayImage = ComponentMethods.createImageGO(HowToPlayImage, "HowToPlayImage", Back);
        HowToPlayImage.GetComponent<Image>().sprite = AssetsHolder.getInstance().HowToPlayImage;
        HowToPlayImage.GetComponent<Image>().SetNativeSize();
        HowToPlayImage = ComponentMethods.setPositionFromParent(HowToPlayImage, RectTransform.Edge.Top, 100f, 600f, RectTransform.Edge.Left, 0f, 1260f);

    }

    // On click methods-----------------------------------------------------------------------------------------------------------
    private void OnClick_Back() 
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSMain);
        // Debug.Log("BACK TO MAIN");
    }
    
}
