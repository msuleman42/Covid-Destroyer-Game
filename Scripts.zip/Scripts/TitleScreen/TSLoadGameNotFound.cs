using UnityEngine;
using UnityEngine.UI;

public class TSLoadGameNotFound : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject NoLoadMessage;
    private GameObject OKButton;
    private GameObject OKText;

    private Color viewBackgroundColor;

    private void Awake()
    {        
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold the input field and button
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3(1f, 1f, 1f), new Vector3(0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (600f, 250f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // Quit heading
        Heading = new GameObject();
        Heading = ComponentMethods.createTextGO(Heading, "NoLoad", Back);
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 0f, 100f, RectTransform.Edge.Left, 0f, 600f);
        Heading = ComponentMethods.setTextProperties(Heading, "LOAD ERROR",
                                                     AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 80, TextAnchor.MiddleCenter, Color.black);

        // Quit message
        NoLoadMessage = new GameObject();
        NoLoadMessage = ComponentMethods.createTextGO(NoLoadMessage, "NoLoadMessage", Back);
        NoLoadMessage = ComponentMethods.setPositionFromParent(NoLoadMessage, RectTransform.Edge.Top, 100f, 50f, RectTransform.Edge.Left, 0f, 600f);
        NoLoadMessage = ComponentMethods.setTextProperties(NoLoadMessage, "No load file detected. Start a new game.",
                                                             AssetsHolder.getInstance().Arial, FontStyle.Normal, 24, TextAnchor.MiddleCenter, Color.black);

        // No Button to return to main title screen
        OKButton = new GameObject();
        OKButton = ComponentMethods.createButtonGO(OKButton, "OKButton", Back);
        OKButton.GetComponent<Image>().color = Color.grey;
        OKButton.GetComponent<Button>().onClick.AddListener(OnClick_OK);
        OKButton = ComponentMethods.setPositionFromParent(OKButton, RectTransform.Edge.Top, 170f, 50f, RectTransform.Edge.Left, 225f, 150f);

        OKText = new GameObject();
        OKText = ComponentMethods.createTextGO(OKText, "OKText", OKButton);
        OKText = ComponentMethods.setPositionFromParent(OKText, RectTransform.Edge.Top, 0f, 50f, RectTransform.Edge.Left, 0f, 150f);
        OKText = ComponentMethods.setTextProperties(OKText, "OK", AssetsHolder.getInstance().Arial, FontStyle.Normal, 30, TextAnchor.MiddleCenter, Color.black);
    }
    
    // Button On Click Methods ------------------------------------------------------------------------------------------
    private void OnClick_OK()
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSMain);
        // Debug.Log("BACK TO MAIN");
    }
}
