using UnityEngine;
using UnityEngine.UI;

public class TSNewGameConfirm : MonoBehaviour
{
    private GameObject Back;
    private GameObject Heading;
    private GameObject NewGameMessage;
    private GameObject YesButton;
    private GameObject NoButton;
    private GameObject YesText;
    private GameObject NoText;

    private Color viewBackgroundColor;

    private void Awake()
    {        
        viewBackgroundColor = new Color(0f, 113f/255f, 90f/255f);
        
        // Panel to hold the input field and button
        Back = new GameObject();
        Back = ComponentMethods.createImageGO(Back, "Panel", this.gameObject, new Vector3(1f, 1f, 1f), new Vector3(0f, 0f, 0f));
        Back.GetComponent<RectTransform>().sizeDelta = new Vector2 (600f, 300f);
        Back.GetComponent<Image>().color = viewBackgroundColor;

        // New game confirmation heading
        Heading = new GameObject();
        Heading = ComponentMethods.createTextGO(Heading, "NewGameConfirmation", Back);
        Heading = ComponentMethods.setPositionFromParent(Heading, RectTransform.Edge.Top, 0f, 100f, RectTransform.Edge.Left, 0f, 600f);
        Heading = ComponentMethods.setTextProperties(Heading, "NEW GAME", AssetsHolder.getInstance().shareTechMono, FontStyle.Bold, 80, TextAnchor.MiddleCenter, Color.black);

        // Quit message
        NewGameMessage = new GameObject();
        NewGameMessage = ComponentMethods.createTextGO(NewGameMessage, "NewGameMessage", Back);
        NewGameMessage = ComponentMethods.setPositionFromParent(NewGameMessage, RectTransform.Edge.Top, 100f, 100f, RectTransform.Edge.Left, 0f, 600f);
        NewGameMessage = ComponentMethods.setTextProperties(NewGameMessage, "Progress in the saved game will be lost. \nAre you sure you would like to start a new game?", 
                                                            AssetsHolder.getInstance().Arial, FontStyle.Normal, 24, TextAnchor.MiddleCenter, Color.black);

        // Yes button to exit game to main title screen
        YesButton = new GameObject();
        YesButton = ComponentMethods.createButtonGO(YesButton, "YesButton", Back);
        YesButton.GetComponent<Image>().color = Color.grey;
        YesButton.GetComponent<Button>().onClick.AddListener(OnClick_Yes);
        YesButton = ComponentMethods.setPositionFromParent(YesButton, RectTransform.Edge.Top, 220f, 50f, RectTransform.Edge.Left, 100f, 150f);

        YesText = new GameObject();
        YesText = ComponentMethods.createTextGO(YesText, "YesText", YesButton);
        YesText = ComponentMethods.setPositionFromParent(YesText, RectTransform.Edge.Top, 0f, 50f, RectTransform.Edge.Left, 0f, 150f);
        YesText = ComponentMethods.setTextProperties(YesText, "YES", AssetsHolder.getInstance().Arial, FontStyle.Normal, 30, TextAnchor.MiddleCenter, Color.black);

        // No Button to return to main title screen
        NoButton = new GameObject();
        NoButton = ComponentMethods.createButtonGO(NoButton, "NoButton", Back);
        NoButton.GetComponent<Image>().color = Color.grey;
        NoButton.GetComponent<Button>().onClick.AddListener(OnClick_No);
        NoButton = ComponentMethods.setPositionFromParent(NoButton, RectTransform.Edge.Top, 220f, 50f, RectTransform.Edge.Right, 100f, 150f);

        NoText = new GameObject();
        NoText = ComponentMethods.createTextGO(NoText, "NoText", NoButton);
        NoText = ComponentMethods.setPositionFromParent(NoText, RectTransform.Edge.Top, 0f, 50f, RectTransform.Edge.Left, 0f, 150f);
        NoText = ComponentMethods.setTextProperties(NoText, "NO", AssetsHolder.getInstance().Arial, FontStyle.Normal, 30, TextAnchor.MiddleCenter, Color.black);
    }

    // Button On Click Methods ------------------------------------------------------------------------------------------
    private void OnClick_Yes()
    {
        // Load level one
        GameController.getInstance().DeletePlayerFile();
        TitleScreen.SwitchView(ViewsTitleScreen.TSEnterName);
        // Debug.Log("Scene Load: LEVEL ONE");
    }

    private void OnClick_No()
    {
        TitleScreen.SwitchView(ViewsTitleScreen.TSMain);
        // Debug.Log("BACK TO MAIN");
    }
}
