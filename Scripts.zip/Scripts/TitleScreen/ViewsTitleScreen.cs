public enum ViewsTitleScreen
{
    TSMain,
    TSSettings,
    TSQuit,
    TSHowToPlay,
    TSHighScores,
    TSNewGameConfirm,
    TSLoadGameNotFound,
    TSEnterName
}
