using System.Collections;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{   
    private int damageAmount;
    private bool isAlive = true;
    [SerializeField]
    private Animator animator;

    void Start() {
        // Set health to max at the start of the level
        GameController.getInstance().setHealth(GameController.getInstance().maxHealth);
        // If user has shield, set the shield animation
        if (GameController.getInstance().hasShield && GameController.getInstance().shield > 0) {
            animator.SetBool("Shield", true);
        }

        // Set the enemy damage output depending on the level its on
        switch(GameController.getInstance().levelNumber) {
            case LevelsEnum.LevelOne:
                damageAmount = AssetsHolder.getInstance().enemyDamageL1;
            break;
            case LevelsEnum.LevelTwo:
                damageAmount = AssetsHolder.getInstance().enemyDamageL2;
            break;
            case LevelsEnum.LevelThree:
                damageAmount = AssetsHolder.getInstance().enemyDamageL3;
            break;
            case LevelsEnum.LevelFour:
                damageAmount = AssetsHolder.getInstance().enemyDamageL4;
            break;
            case LevelsEnum.LevelFive:
                damageAmount = AssetsHolder.getInstance().enemyDamageL5;
            break;
            case LevelsEnum.LevelSix:
                damageAmount = AssetsHolder.getInstance().enemyDamageL6;
            break;
        }
    }

    // // NEED TO DELETE THIS UPDATE METHOD IN ACTUAL BUILD--------------------
    // // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            TakeDamage(50);
            // Debug.Log(GameController.getInstance().health);
        }
    }

    private void TakeDamage(int damage)
    {
        // decrease the health or shield if damage is taken
        if(GameController.getInstance().hasShield && GameController.getInstance().shield > 0)
        {
            GameController.getInstance().AddShield(-damage);
            // if the shield is less than 0, set the animation to no shield
            if (GameController.getInstance().shield <= 0) {
                animator.SetBool("Shield", false);
            }
        }
        else 
        {
            GameController.getInstance().AddHealth(-damage);
        }
        
    }

    // if bullet hits the game object the script is attached to (i.e. the player) then do this
    void OnTriggerEnter2D (Collider2D col)
    {
        // if the object that collides with the player is a bullet then player takes damage
        if(col.gameObject.tag.Equals("Bullet"))
        {
            TakeDamage(damageAmount);
            // if player health is 0 or less, destroy the object
            if(GameController.getInstance().health <= 0)
            {
                StartCoroutine(onDeath());
            }
        }
    }

    private IEnumerator onDeath()
    {
        // Debug.Log("Player Dead");
        // On death do this:
        if(isAlive) {
            // Destroy all children (the bullets)
            foreach (Transform child in gameObject.transform) {
                GameObject.Destroy(child.gameObject);
            }
            // play death animation and sound and wait for it to finish before destroying object
            animator.SetBool("Death", true);
            AudioController.getInstance().playerDeath();
            isAlive = false;
            yield return new WaitForSeconds(2f);
            GameController.getInstance().playerDead = true;
            Destroy(gameObject);
        }
    }
}
