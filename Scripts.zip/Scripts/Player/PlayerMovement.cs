using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField]
    private float moveSpeed = 5f;
    [SerializeField]
    private Rigidbody2D player;
    [SerializeField]
    private Animator animator;
    
    private Vector2 movement;

    void Awake()
    {
        // set the movement speed of the player
        moveSpeed = GameController.getInstance().movementSpeed;
    }
    
    void FixedUpdate()
    {
        // Movement
        player.MovePosition(player.position + movement * moveSpeed * Time.fixedDeltaTime);
        // Set animation
        animator.SetFloat("Speed", movement.x * 100f);
    }

    // Update is called once per frame
    void Update()
    {
        // Inputs for movement
        movement.x = Input.GetAxisRaw("Horizontal");
    }

}
