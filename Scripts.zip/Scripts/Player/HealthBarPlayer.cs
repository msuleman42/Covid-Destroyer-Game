using UnityEngine;
using UnityEngine.UI;

public class HealthBarPlayer : MonoBehaviour
{
    [SerializeField]
    private Slider slider;
    [SerializeField]
    private Gradient gradient;
    [SerializeField]
    private Image fill;

    void Start()
    {
        // Show the health values on the UI in the way of a bar/slider
        SetMaxHealth(GameController.getInstance().maxHealth);
        SetHealth(GameController.getInstance().health);
    }

    void Update()
    {
        // Read the health value on each update
        SetHealth(GameController.getInstance().health);
    }
    
    // set health values on slider
    private void SetHealth(int health)
    {
        slider.value = health;
        fill.color = gradient.Evaluate(slider.normalizedValue);
    }
    // set max value of slider
    private void SetMaxHealth(int maxHealth)
    {
        slider.maxValue = maxHealth;
    }
}
