using UnityEngine;
using UnityEngine.UI;

public class ShieldBar : MonoBehaviour
{
    [SerializeField]
    private Slider slider;
    [SerializeField]
    private Image fill;

    void Awake()
    {
        // Show the shield values on the UI in the way of a bar/slider
        SetMaxShield(GameController.getInstance().maxShield);
        SetShield(GameController.getInstance().shield);
    }

    void Update()
    {
        // Read the shield value on each update
        SetShield(GameController.getInstance().shield);
    }

    // set shield values on slider
    private void SetShield(int shield)
    {
        slider.value = shield;
    }
    // set max value of the slider
    private void SetMaxShield(int maxShield)
    {
        slider.maxValue = maxShield;
    }
}
