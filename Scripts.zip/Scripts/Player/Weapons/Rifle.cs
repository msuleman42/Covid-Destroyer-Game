using UnityEngine;

public class Rifle : MonoBehaviour
{
    private GameObject bulletInst;

    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;

    private float nextFire = 0f;
    private float fireRate = 0.4f;

    // Frame rate independent update
    void FixedUpdate()
    {
        // If fire button(mouse click) or space is pressed or held down, shoot weapon as long as fire rate allows
        if ((Input.GetButtonDown("Fire1") || Input.GetButton("Fire1") || Input.GetKeyDown(KeyCode.Space) || Input.GetKey(KeyCode.Space)) 
            && Time.time > nextFire && firePoint != null) {
            nextFire = Time.time + fireRate;
            Shoot();
        }
    }

    void Shoot()
    {
        bulletInst = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, 0f));
        bulletInst.transform.SetParent(this.transform);
        bulletInst.transform.localScale = new Vector3(1f, 1f, 1f);
        AudioController.getInstance().playerShoot(WeaponsEnum.Rifle);
    }
}
