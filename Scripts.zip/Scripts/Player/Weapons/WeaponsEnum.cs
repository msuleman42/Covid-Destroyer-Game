
public enum WeaponsEnum
{
    Pistol,
    DualPistol,
    Rifle,
    Shotgun
}
