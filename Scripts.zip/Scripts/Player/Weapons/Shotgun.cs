using UnityEngine;

public class Shotgun : MonoBehaviour
{
    private GameObject bulletInst1;
    private GameObject bulletInst2;
    private GameObject bulletInst3;

    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;
    
    private float nextFire = 0f;
    private float fireRate = 0.7f;

    // Frame rate independent update
    void FixedUpdate()
    {
        // If fire button(mouse click) or space is pressed or held down, shoot weapon as long as fire rate allows
        if ((Input.GetButtonDown("Fire1") || Input.GetButton("Fire1") || Input.GetKeyDown(KeyCode.Space) || Input.GetKey(KeyCode.Space)) 
                && Time.time > nextFire && firePoint != null) {
            nextFire = Time.time + fireRate;
            Shoot();
        }
    }

    void Shoot()
    {
        // instantiate bullet. bullets 2 and 3 at an angle to spread the bullets like a shotgun
        bulletInst1 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, 0f));
        bulletInst1.transform.SetParent(this.transform);
        bulletInst1.transform.localScale = new Vector3(1f, 1f, 1f);
        bulletInst2 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, -4f));
        bulletInst2.transform.SetParent(this.transform);
        bulletInst2.transform.localScale = new Vector3(1f, 1f, 1f);
        bulletInst3 = Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0f, 0f, 4f));
        bulletInst3.transform.SetParent(this.transform);
        bulletInst3.transform.localScale = new Vector3(1f, 1f, 1f);
        AudioController.getInstance().playerShoot(WeaponsEnum.Shotgun);
    }
}
